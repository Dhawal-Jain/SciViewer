
#' Function to plot columns using highcharter
#'
#' the function takes range of input parameters to draw interactive highcharter column plot
#' The returned object is a highcharter object
#' @param pl Input dataframe
#' @param features column name/s from the dataframe to be used for grouping the data along x-axis (default: cell_type)\
#' @param ycol column name for y-axis value (default: value)
#' @param log.transform logical, whether to transform the data (default:F)
#' @param main plot title
#' @param xlab x-axis label
#' @param ylab y-axis label (default: average expression <br/>(TPM))
#' @param min.cel.number minimum number of cells/samples per group to be used for display (default: 0)
#' @param plotType type of plot i.e. count or expression (default: count)
#' @param sourceref reference source label for the figure (default: pDDSingleCellApp)
#' @param sampleType type of samples i.e. cells or samples; used for data hover label (default: cells)
#' @param sortdata logical, whether to sort the data (default: T)
#' @import dplyr
#' @import highcharter
#' @return highchart plot object
#' @export
## column plot function
dhc_columnPlot <- function(pl, features='cell_type',ycol='value',
                           log.transform = F,
                           main="",xlab="",
                           ylab="average expression <br/>(TPM)",
                           min.cell.number=0,
                           plotType='count',sourceref='pDDSingleCellApp',
                           sampleType='cells',sortdata=T){

  gl <- pl
  ## consider first two features for x faceting
  if(length(features)>2){
    features = features[1:2]
  }
  ## datra transform
  if(log.transform==T){
    gl[,ycol] <- log2(gl[,ycol]+1)
  }
  ## counts
  z <- gl %>%
    dplyr::group_by_at(features) %>% dplyr::select(dplyr::all_of(ycol)) %>%
    dplyr::summarise_all(c(mean,pddExpn::sem,length))
  z <- as.data.frame(z)
  z <- unique(z)

  if(length(features)==1){
    names(z) <- c("group","average","ci","total_number")
    z$group <- as.character(z$group)
  }else{
    names(z) <- c("group","subgroup","average","ci","total_number")
    z$group <- as.character(z$group)
    z$subgroup <- as.character(z$subgroup)
  }
  z[,c("average","ci")] <- round(z[,c("average","ci")],3)

  if(!is.null(min.cell.number)){
    z <- z[z$total_number>=min.cell.number,]
  }
  z$ci <- z$ci*1.96
  z$fraction <- round(z$total_number*100/sum(z$total_number),3)

  ## colors
  if(length(features)==1){
    cols <- pddExpn::myCol.fun(k = length(unique(z$group)))
    if(is.null(cols)){
      cols <- pddExpn::myCol.fun(k = 42)
      cols <- rep(cols,10)[1:length(unique(z$group))]
      if(is.null(cols)){
        cols='#bdbdbd'
      }
    }
    colorByPoint = T
  }else if(length(features)==2){
    cols='#bdbdbd'
    colorByPoint=F
  }else{
    stop('Error! This highchart function does not provide grouping support on more than one feature\n')
  }

  ## plot repurpose
  if(plotType=='count'){
    z$average <- z$fraction
    z$ci <- NA
  }

  if(sortdata==T){
    z <- z[order(z$average,decreasing = T),]
  }


  if(length(features)==1){
    hc <- hchart(z,'column',hcaes(x=group,y=average),
                 fast=T,
                 boost=T,
                 showInLegend =F
    ) %>%
      hc_add_series(z,"errorbar",
                    hcaes(low = average -ci,
                          high = average + ci),
                    showInLegend=F
      )
  }else{
    hc <- hchart(z,'column',hcaes(x=group,y=average,group = subgroup),
                 fast=T,
                 boost=T,
                 showInLegend =T
    )%>%
      hc_add_series(z,"errorbar",grouping=T,
                    hcaes(x=group,y=average,
                          low = average -ci,
                          high = average + ci,
                          group = subgroup),
                    showInLegend=F
      )
  }

  hc <- hc %>%
    hc_chart(zoomType = "xy",
             borderColor = "#EBBA95",
             borderRadius = 10,
             borderWidth = 3,
             plotShadow = F,
             allowForce = T,
             turboThreshold =1,
             allowForce=T,
             animation=T,
             boostThreshold = 1,
             usePreallocated = T,
             useGPUTranslations =T,
             seriesThreshold = 2
    ) %>%
    hc_plotOptions(
      errorbar = list(
        color = 'black',
        centerInCategory = T,
        grouping=T
      ),
      column=list(
        colors=cols,
        centerInCategory = T,
        grouping=T,
        colorByPoint=colorByPoint
      )
    ) %>%
    hc_title(text = main,
             style = list(fontSize = "20px")
    ) %>%
    hc_credits(
      enabled = TRUE,
      text = paste0("Source:",sourceref),
      href = "",
      style = list(fontSize = "11px")
    ) %>%
    hc_xAxis(title = list(text =xlab),
             opposite = F,
             #categories = z$group,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,
             showLastLabel = T,
             style = list(fontSize = "20px")
    ) %>%
    hc_yAxis(title = list(text = ylab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,showLastLabel = T,
             style = list(fontSize = "20px")
    )%>%
    hc_exporting(enabled=T
    ) %>%
    hc_scrollbar(
      barBackgroundColor = "gray",
      barBorderRadius = 7,
      barBorderWidth = 0,
      buttonBackgroundColor = "gray",
      buttonBorderWidth = 0,
      buttonArrowColor = "yellow",
      buttonBorderRadius = 7,
      rifleColor = "yellow",
      trackBackgroundColor = "white",
      trackBorderWidth = 1,
      trackBorderColor = "silver",
      trackBorderRadius = 7
    )%>%
    hc_boost(enabled=T)

  hc$x$hc_opts$boost$enabled <- T

  if(plotType=='count'){
    hc <- hc %>% hc_tooltip(
      useHTML = TRUE,
      pointFormat = paste0(
        "<span style=\"color:{series.color};\">{series.options.icon}</span>",
        "<b>#",sampleType,":</b> {point.total_number}</b><br/>",
        "<b>% of ",sampleType,":</b> {point.average}%</b><br/>")
    )
  }else{
    hc <- hc %>% hc_tooltip(
      useHTML = TRUE,
      pointFormat = paste0(
        "<span style=\"color:{series.color};\">{series.options.icon}</span>",
        "<b>#",sampleType,": </b>{point.total_number}</b><br/>",
        "<b>Average:</b> {point.average}</b><br/>",
        "<b>95%CI:</b> {point.ci}<br/>")
    )
  }

  return(hc)
}


#' Function to plot boxplot using highcharter
#'
#' the function takes range of input parameters to draw interactive highcharter box plot
#' The returned object is a highcharter object
#' @param pl Input dataframe
#' @param features column name/s from the dataframe to be used for grouping the data along x-axis (default: cell_type)
#' @param ycol column name for y-axis value (default: value)
#' @param log.transform logical, whether to transform the data (default:F)
#' @param main plot title
#' @param xlab x-axis label
#' @param ylab y-axis label (default: average expression <br/>(TPM))
#' @param sourceref reference source label for the figure (default: pDDSingleCellApp)
#' @import dplyr
#' @import highcharter
#' @return highchart plot object
#' @export
## box plot function
dhc_boxPlot <- function(pl, features='cell_type',ycol='value',
                        log.transform = F,
                        main="",xlab="",
                        ylab="average expression <br/>(TPM)",
                        sourceref='pDDSingleCellApp'){
  ## consider first two features for x faceting
  if(length(features)>2){
    features = features[1:2]
  }

  ## create data frame
  gl <- pl[,c(ycol,features)]
  ## datra transform
  if(log.transform==T){
    gl$value <- round(log2(gl$value+1),2)
  }

  # non-functional code hashed out
  #z <- gl %>%
  #  dplyr::group_by_at(features[1]) %>% dplyr::select(dplyr::all_of(ycol)) %>%
  #  dplyr::summarise_all(median)
  #names(z) = c('category','val')
  #z <- z[order(z$category,decreasing = F),]
  #gl[,features[1]] <- factor(gl[,features[1]],levels=z$category)

  ## create data frame for hc
  if(length(features)==1){
    names(gl) <- c('value','group')
    dat <- data_to_boxplot(data = gl,
                           variable = value,
                           group_var = group,
                           add_outliers = F)
  }else if(length(features)==2){
    names(gl) <- c('value','group','subgroup')
    dat <- data_to_boxplot(data = gl,
                           variable = value,
                           group_var = group,
                           group_var2 = subgroup,
                           add_outliers = F)
  }


  ## colors
  if(length(features)==1){
    k = length(unique(as.character(gl$group)))
    cols <- pddExpn::myCol.fun(k = k)
    if(is.null(cols)){
      cols <- pddExpn::myCol.fun(k = 42)
      cols <- rep(cols,10)[1:k]
      if(is.null(cols)){
        cols='#bdbdbd'
      }
    }
    colorByPoint = T
  }else if(length(features)==2){
    cols='#bdbdbd'
    colorByPoint=F
  }else{
    stop('Error! This highchart function does not provide grouping support on more than one feature\n')
  }

  ## create plot
  hc <- highchart() %>%
    hc_xAxis(type = "category") %>%
    hc_add_series_list(dat)
  hc <- hc %>%
    hc_chart(zoomType = "xy",
             borderColor = "#EBBA95",
             borderRadius = 10,
             borderWidth = 3,
             plotShadow = F,
             allowForce = T,
             turboThreshold =1,
             allowForce=T,
             animation=T,
             boostThreshold = 1,
             usePreallocated = T,
             useGPUTranslations =T,
             seriesThreshold = 2
    ) %>%
    hc_plotOptions(
      series=list(
        colors=cols,
        centerInCategory = T,
        colorByPoint=colorByPoint
      )
    ) %>%
    hc_title(text = main,
             style = list(fontSize = "20px")
    ) %>%
    hc_credits(
      enabled = TRUE,
      text = paste0("Source:",sourceref),
      href = "",
      style = list(fontSize = "11px")
    ) %>%
    hc_xAxis(title = list(text =xlab),
             opposite = F,
             #categories = z$group,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,
             showLastLabel = T,
             style = list(fontSize = "20px")
    ) %>%
    hc_yAxis(title = list(text = ylab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,showLastLabel = T,
             style = list(fontSize = "20px")
    )%>%
    hc_exporting(enabled=T
    ) %>%
    hc_scrollbar(
      barBackgroundColor = "gray",
      barBorderRadius = 7,
      barBorderWidth = 0,
      buttonBackgroundColor = "gray",
      buttonBorderWidth = 0,
      buttonArrowColor = "yellow",
      buttonBorderRadius = 7,
      rifleColor = "yellow",
      trackBackgroundColor = "white",
      trackBorderWidth = 1,
      trackBorderColor = "silver",
      trackBorderRadius = 7
    )%>%
    hc_boost(enabled=T)


  hc$x$hc_opts$boost$enabled <- T

  return(hc)
}


#' Function to plot correlation value plot for a symetric matrix
#'
#' the function takes range of input parameters to draw interactive highcharter correlation heat plot
#' The returned object is a highcharter object
#' @param mcor nXn correlation value matrix
#' @param sourceref reference source label for the figure (default: pDDSingleCellApp)
#' @import dplyr
#' @import highcharter
#' @return highchart plot object
#' @export
## correlation plot function
hchart_cor <- function(mcor,sourceref='pDDSingleCellApp') {

  mcor <- round(mcor,2)
  mcor[is.na(mcor)] = 0

  fntltp <- JS("function(){
                  return this.series.xAxis.categories[this.point.x] + ' ~ ' +
                         this.series.yAxis.categories[this.point.y] + ': <b>' +
                         Highcharts.numberFormat(this.point.value, 2)+'</b>';
               ; }")
  cor_colr <- list( list(0, '#FF5733'),
                    list(0.5, '#F8F5F5'),
                    list(1, '#2E86C1')
  )

  hs <- hchart(mcor) %>%
    hc_plotOptions(
      series = list(
        boderWidth = 0,
        dataLabels = list(enabled = TRUE)
      ))   %>%
    hc_legend(align = "right", layout = "vertical") %>%
    hc_colorAxis(  stops= cor_colr,min=-1,max=1)
  hs <- hs %>%
    hc_credits(
      enabled = TRUE,
      text = paste0("Source:",sourceref),
      href = "",
      style = list(fontSize = "11px")
    )%>%
    hc_exporting(enabled=T
    ) %>%
    hc_scrollbar(
      barBackgroundColor = "gray",
      barBorderRadius = 7,
      barBorderWidth = 0,
      buttonBackgroundColor = "gray",
      buttonBorderWidth = 0,
      buttonArrowColor = "yellow",
      buttonBorderRadius = 7,
      rifleColor = "yellow",
      trackBackgroundColor = "white",
      trackBorderWidth = 1,
      trackBorderColor = "silver",
      trackBorderRadius = 7
    ) %>%
    hc_chart(zoomType = "xy",
             borderColor = "#EBBA95",
             borderRadius = 10,
             borderWidth = 3,
             plotShadow = F,
             allowForce = T,
             turboThreshold =1,
             allowForce=T,
             animation=T,
             boostThreshold = 1,
             usePreallocated = T,
             useGPUTranslations =T,
             seriesThreshold = 2
    )

  return(hs)
}



#' Function to plot scatter using highcharter
#'
#' the function takes range of input parameters to draw interactive highcharter scatter plot
#' The returned object is a highcharter object
#' @param pl Input dataframe
#' @param x x-axis column name (default: V1)
#' @param y y-axis column name (default: V2)
#' @param clustCol Column containing grouping information for the data (default: louvain)
#' @param expnCol column containing expression/variable values (default: NULL)
#' @param log.transform logical, whether to transform the data (default:F)
#' @param main plot title
#' @param xlab x-axis label (default: Z_coordinate_1)
#' @param ylab y-axis label (default: Z_coordinate_2)
#' @param sourceref reference source label for the figure (default: pDDSingleCellApp)
#' @import dplyr
#' @import highcharter
#' @return highchart plot object
#' @export
## scatter plot function
dhc_2dscatter <- function(pl, x='V1',y='V2',
                          clustCol='louvain',
                          expnCol=NULL,
                          log.transform = F,
                          main="",xlab="Z_coordinate_1",
                          ylab="Z_coordinate_2",
                          sourceref='pDDSingleCellApp'){

  if(is.null(clustCol) | clustCol==""){
    stop('Cluster column is not reported! ')
  }

  gl <- pl[,c('SAMPID',x,y,clustCol,expnCol)]
  if(!is.null(expnCol)){
    names(gl) <- c('SAMPID','x','y','grp','value')
    ## datra transform
    if(log.transform==T){
      gl$value <- round(log2(gl$value+1),2)
    }
  }else{
    names(gl) <- c('SAMPID','x','y','grp')
  }
  head(gl)

  ## colors
  if(!is.null(clustCol) | clustCol!=""){
    k = length(unique(as.character(gl$grp)))
    cols <- pddExpn::myCol.fun(k = k)
    if(is.null(cols)){
      cols <- pddExpn::myCol.fun(k = 42)
      cols <- rep(cols,10)[1:k]
      if(is.null(cols)){
        cols='#bdbdbd'
      }
    }
  }else{
    k = length(unique(as.character(gl$grp)))
    cols=rep('#bdbdbd',k)
  }

  ## define point size
  radius = 10
  if(nrow(gl)>500){
    radius=5
  }
  if(nrow(gl)>1000){
    radius=1.5
  }
  if(nrow(gl)>5000){
    radius=0.5
  }

  ## create plot
  if(is.null(expnCol)){
    hc <- gl %>%
      hchart('scatter',fast=T, hcaes(x = x, y = y,group= grp),
             fillOpacity = 0.1,
             boostThreshold = 1,
             marker = list(symbol='circle',radius = radius)
      )
    hc <- hc %>% hc_colors(cols)
  }else{
    hc <- gl %>%
      hchart('scatter',fast=T, hcaes(x = x, y = y,color=value),
             fillOpacity = 0.1,
             boostThreshold = 1,
             colorKey="value",
             marker = list(symbol='circle',radius = radius)
      )
  }

  hc <- hc %>%
    hc_chart(zoomType = "xy",
             borderColor = "#EBBA95",
             borderRadius = 10,
             borderWidth = 3,
             plotShadow = F,
             allowForce = T,
             turboThreshold =1,
             allowForce=T,
             animation=T,
             boostThreshold = 1,
             usePreallocated = T,
             useGPUTranslations =T,
             seriesThreshold = 2
    ) %>%
    hc_legend(align='right',
              verticalAlign = "top",
              layout = "vertical"
    ) %>%
    hc_title(text = main,
             style = list(fontSize = "20px")
    ) %>%
    hc_credits(
      enabled = TRUE,
      text = paste0("Source:",sourceref),
      href = "",
      style = list(fontSize = "11px")
    )%>%
    hc_xAxis(title = list(text =xlab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,
             showLastLabel = T,
             style = list(fontSize = "20px")
    ) %>%
    hc_yAxis(title = list(text = ylab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,showLastLabel = T,
             style = list(fontSize = "20px")
    )%>%
    hc_exporting(enabled=T
    ) %>%
    hc_scrollbar(
      barBackgroundColor = "gray",
      barBorderRadius = 7,
      barBorderWidth = 0,
      buttonBackgroundColor = "gray",
      buttonBorderWidth = 0,
      buttonArrowColor = "yellow",
      buttonBorderRadius = 7,
      rifleColor = "yellow",
      trackBackgroundColor = "white",
      trackBorderWidth = 1,
      trackBorderColor = "silver",
      trackBorderRadius = 7
    )%>%
    hc_boost(enabled=T)
  hc$x$hc_opts$boost$enabled <- T

  hc <- hc %>% hc_tooltip(useHTML = TRUE,
                          pointFormat = paste0(
                            "<span style=\"color:{series.color};\">{series.options.icon}</span>",
                            "<b>SampleID:</b>{point.SAMPID}<br/>",
                            "<b>ClusterID:</b>{point.grp}<br/>",
                            ifelse(!is.null(expnCol),"<b>Expression:</b>{point.value}<br/>",""),
                            "<b>[{point.x}, {point.y}]</b><br/>"))

  return(hc)
}


#' Function to plot grouped-scatter using highcharter
#'
#' the function takes range of input parameters to draw interactive highcharter grouped-scatter plot
#' The returned object is a highcharter object
#' @param pl Input dataframe
#' @param main plot title
#' @param xlab x-axis label (default: Z_coordinate_1)
#' @param ylab y-axis label (default: Z_coordinate_2)
#' @param groupVar Column containing grouping information for the data (default: lineage)
#' @param plotType type of plot i.e. grouped / sorted (default: grouped)
#' @param sourceref reference source label for the figure (default: pDDSingleCellApp)
#' @import dplyr
#' @import highcharter
#' @return highchart plot object
#' @export
## grouped-scatter plot function
dhc_ccleExpn <- function(pl,main="",xlab="Cell lineages",
                         ylab="Normalized expression<br>(log2 scale)",
                         groupVar="lineage",
                         plotType='grouped',sourceref='pDDExpressionApp'){

  ## This is a highly customized, data-specific plot function
  gl <- pl[,c('cell_line_name','sex','sample_collection_site',
              'primary_disease','value',groupVar)]
  names(gl)[ncol(gl)] <- "grp"
  gl$grp <- as.character(gl$grp)
  gl$grp <- ifelse(gl$grp=="",as.character('Unavailable'),as.character(gl$grp))

  gl <- gl[order(gl$value,decreasing = F),]
  gl$xid = 1:nrow(gl)

  if(plotType=='grouped'){
    hc <- gl %>%
      hchart('scatter',fast=T, hcaes(x = cell_line_name, y = value,group= grp),
             fillOpacity = 0.1,
             boostThreshold = 1,
             showInLegend=T,
             marker = list(symbol='circle',radius = 2)
      )
  }else{
    hc <- gl %>%
      hchart('scatter',fast=T, hcaes(x = xid, y = value,group= grp),
             fillOpacity = 0.1,
             boostThreshold = 1,
             showInLegend=T,
             marker = list(symbol='circle',radius = 2)
      )
  }
  hc <- hc %>%
    hc_legend(align='right',
              verticalAlign = "top",
              layout = "vertical"
    ) %>%
    hc_chart(zoomType = "xy",
             borderColor = "#EBBA95",
             borderRadius = 10,
             borderWidth = 3,
             plotShadow = F,
             allowForce = T,
             turboThreshold =1,
             allowForce=T,
             animation=T,
             boostThreshold = 1,
             usePreallocated = T,
             useGPUTranslations =T,
             seriesThreshold = 2
    ) %>%
    hc_title(text = main,
             style = list(fontSize = "20px")
    ) %>%
    hc_credits(
      enabled = TRUE,
      text = paste0("Source:",sourceref),
      href = "",
      style = list(fontSize = "11px")
    )%>%
    hc_xAxis(title = list(text =xlab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,
             showLastLabel = T,
             style = list(fontSize = "20px")
    ) %>%
    hc_yAxis(title = list(text = ylab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,showLastLabel = T,
             style = list(fontSize = "20px")
    )%>%
    hc_exporting(enabled=T
    ) %>%
    hc_scrollbar(
      barBackgroundColor = "gray",
      barBorderRadius = 7,
      barBorderWidth = 0,
      buttonBackgroundColor = "gray",
      buttonBorderWidth = 0,
      buttonArrowColor = "yellow",
      buttonBorderRadius = 7,
      rifleColor = "yellow",
      trackBackgroundColor = "white",
      trackBorderWidth = 1,
      trackBorderColor = "silver",
      trackBorderRadius = 7
    )%>%
    hc_boost(enabled=T)

  hc$x$hc_opts$boost$enabled <- T
  hc <- hc %>% hc_tooltip(useHTML = TRUE,
                          pointFormat = paste0(
                            "<span style=\"color:{series.color};\">{series.options.icon}</span>",
                            "<b>Cell Line: </b>{point.cell_line_name}<br/>",
                            "<b>",groupVar,": </b>{point.grp}<br/>",
                            "<b>Primary disease: </b>{point.primary_disease}<br/>",
                            "<b>Site: </b>{point.sample_collection_site}<br/>",
                            "<b>Expression: </b>{point.y}<br/>"))

  return(hc)

}



#' Function to plot stacked-barr using highcharter
#'
#' the function takes range of input parameters to draw interactive highcharter staked-bar plot
#' The returned object is a highcharter object
#' @param pl Input dataframe
#' @param chart.type type of chart to make i.e. bar
#' @param x x-axis value (default: var1)
#' @param y y-axis value (default: value)
#' @param grp group variable (default: grp)
#' @param main plot title
#' @param xlab x-axis label (default: Z_coordinate_1)
#' @param ylab y-axis label (default: Z_coordinate_2)
#' @param sourceref reference source label for the figure (default: pDDSingleCellApp)
#' @import dplyr
#' @import highcharter
#' @return highchart plot object
#' @export
## tacked bar plot function
dhc_stackBars <- function(pl,chart.type='bar',
                          x='Var1',y='value',grp='variable',
                          main="",xlab="Z_coordinate_1",
                          ylab="Z_coordinate_2",
                          sourceref='pDDSingleCellApp'){

  kfeat = pl[,'variable'] %>% unique() %>% length()
  cols='#bdbdbd'
  if(kfeat>0){
    cols <- pddExpn::myCol.fun(k = kfeat)
    if(is.null(cols)){
      cols <- pddExpn::myCol.fun(k = 42)
      cols <- rep(cols,10)[1:kfeat]
      if(is.null(cols)){
        cols='#bdbdbd'
      }
    }
    colorByPoint = T
  }

  hc <- hchart(pl, type = 'bar', fast=T,
               hcaes( x = Var1, group=variable, y = value)) %>%
    hc_plotOptions(series = list(stacking = "normal"))
  hc <- hc %>%
    hc_chart(zoomType = "xy",
             borderColor = "#EBBA95",
             borderRadius = 10,
             borderWidth = 3,
             plotShadow = F,
             allowForce = T,
             turboThreshold =1,
             allowForce=T,
             animation=T,
             boostThreshold = 1,
             usePreallocated = T,
             useGPUTranslations =T,
             seriesThreshold = 2
    ) %>%
    hc_colors(cols
    )%>%
    hc_title(text = main,
             style = list(fontSize = "20px")
    ) %>%
    hc_credits(
      enabled = TRUE,
      text = paste0("Source:",sourceref),
      href = "",
      style = list(fontSize = "11px")
    ) %>%
    hc_xAxis(title = list(text =xlab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,
             showLastLabel = T,
             style = list(fontSize = "20px")
    ) %>%
    hc_yAxis(title = list(text = ylab),
             opposite = F,
             alternateGridColor = "white",
             minorTickInterval = "auto",
             minorGridLineDashStyle = "LongDashDotDot",
             showFirstLabel = T,showLastLabel = T,
             style = list(fontSize = "20px")
    )%>%
    hc_exporting(enabled=T
    ) %>%
    hc_scrollbar(
      barBackgroundColor = "gray",
      barBorderRadius = 7,
      barBorderWidth = 0,
      buttonBackgroundColor = "gray",
      buttonBorderWidth = 0,
      buttonArrowColor = "yellow",
      buttonBorderRadius = 7,
      rifleColor = "yellow",
      trackBackgroundColor = "white",
      trackBorderWidth = 1,
      trackBorderColor = "silver",
      trackBorderRadius = 7
    )%>%
    hc_boost(enabled=T)

  hc$x$hc_opts$boost$enabled <- T
  hc
}


