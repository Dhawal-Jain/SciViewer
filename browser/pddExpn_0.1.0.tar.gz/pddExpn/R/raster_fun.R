
#' Function to plot rasterized scatter plot
#'
#' the function takes range of input parameters to draw interactive high-density scatter plot
#' The returned object is a plotly object
#' @param pl Input dataframe
#' @param x x-axis column name (default: V1)
#' @param y y-axis column name (default: V2)
#' @param feature column name from the dataframe to be used for grouping the data along x-axis (default: cell_type)\
#' @param genename name of the gene used as plot title
#' @param selectedFeature set of features used for subsetting the data
#' @param legendPlot Logical, whether to plot legends only
#' @param source.val plot identifier
#' @param js javascript pluggin on on-render plot interactions
#' @import plotly
#' @import dplyr
#' @importFrom rasterly plotRasterly
#' @importFrom htmlwidgets onRender
#' @return plotly plot object
#' @export
## high density scatter plot function
plot_umap_raster <- function(pl,x='V1',y='V2',feature='cell_type',
                             genename='SFTPD',
                             selectedFeature=NULL,
                             legendPlot=F, source.val = NULL, js=NULL){
  ## this functions makes two kinds of plots
  ## 1. the raster UMAP without legends
  ## 2. the plotly plot for legends
  ## these need to be rendered side-by-side inthe shiny application
  ## additional development is needed
  if(!isTruthy(pl) | !isTRUE(nrow(pl)>0)){
    return(NULL)
  }

  if(!x%in%names(pl) | !y%in%names(pl) | !feature%in%names(pl)){
    #stop('Error! provided column names are not presented in the data table.\n')
  }
  ## create new data frame
  gl <- data.frame(x=as.numeric(pl[,x]),
                   y=as.numeric(pl[,y]),
                   feature=pl[,feature])
  gl <- gl[complete.cases(gl),]

  cols <- pddExpn::myCol.fun(k = length(unique(gl$feature)))
  if(is.null(cols)){
    cols <- pddExpn::myCol.fun(k = 42)
    cols <- rep(cols,10)[1:length(unique(gl$feature))]
    if(is.null(cols)){
      cols='gray'
    }
  }
  gl$feature <- factor(gl$feature, levels=unique(gl$feature))
  coldf <- data.frame(feature=levels(gl$feature),
                      col=cols,stringsAsFactors = F)

  anno <- list(
    text = genename,
    font=list(size=18),
    yanchor = "bottom",
    xanchor = "center",
    align = "center",
    x = max(gl$x,na.rm = T)/2,
    y = max(gl$y,na.rm = T)*1.0,
    showarrow = FALSE
  )
  if(legendPlot==T){
    ax <- list(
      title = "",
      zeroline = FALSE,
      showline = FALSE,
      showticklabels = FALSE,
      showgrid = FALSE
    )

    legdf <- data.frame(x=0,y=0,feature=unique(gl$feature))
    leg <- plot_ly(data = legdf, x = ~x, y = ~y,color=~feature,
                   colors=cols,
                   mode='scatter',type='scatter')%>%
      layout(legend = list(x=0,y=Inf)) %>%
      layout(xaxis = ax, yaxis = ax) %>%
      config(displayModeBar = F) %>%
      htmlwidgets::onRender("function(el,x){el.on('plotly_legendclick', function(){ return false; })}")

    return(leg)

  }else{

    if(!is.null(selectedFeature)){
      if(selectedFeature%in%levels(gl$feature)){
        coldf[!coldf$feature%in%selectedFeature,]$col <- '#f0f0f0'
        cols <- as.character(coldf$col)
      }
    }

    p <- gl %>%
      rasterly::plotRasterly(aes(x=x,y=y,col=feature),
                   color = cols,show_raster = T,drop_data = T,
                   as_image = T,variable_check = T)
    p <- p %>% layout(annotations = anno)
    p$x$layoutAttrs[[1]]$xaxis$title <- "Z_coordinate_1"
    p$x$layoutAttrs[[1]]$yaxis$title <- "Z_coordinate_2"

    if(!is.null(source.val)){
      p[["x"]][["source"]] <- source.val
      environment(p[["x"]][["visdat"]][[1]])[["p"]][["source"]] <- source.val
      environment(p[["x"]][["visdat"]][[1]])[["source"]] <- source.val
    }

    if(!is.null(js) & !is.null(source.val)){
      p <- p %>% htmlwidgets::onRender(jsCode = js,data = source.val)
    }
    return(p)
  }

}



#' Function to plot rasterized multi-scatter plots
#'
#' the function takes range of input parameters to draw interactive high-density multi-scatter plots
#' The returned object is a plotly object
#' @param pldf List of dataframes per gene, used for making multiple scatter plots
#' @param x x-axis column name (default: V1)
#' @param y y-axis column name (default: V2)
#' @param ycol value to be used for projection on the plot
#' @param xrange range of x-axis values for subsetting the datasets
#' @param yrange range of y-axis values for subsetting the datasets
#' @param legendPlot logical, whether to plot only legends (default:F)
#' @param configlayout logical, whether to configure the plot layout (default: T)
#' @param log.transform logical, whether to transform the data (default:F)
#' @param colScale color scale used for projection, a set of 3 colors min,mid,max
#' @param minValCol color used for the lowest value
#' @import plotly
#' @import dplyr
#' @importFrom rasterly plotRasterly
#' @importFrom htmlwidgets onRender
#' @return plotly plot object
#' @export
## high density multi-scatter plot function
plot_multi_umap_raster <- function(pldf,genenames=NULL,
                                   x='V1',y='V2',ycol='value',
                                   xrange=NULL, yrange=NULL,
                                   legendPlot=F,configlayout=T,
                                   log.transform=F,
                                   colScale=c("#fcfbfd", "#9e9ac8", "#3f007d"),
                                   minValCol="#f0f0f0"){
  #q <- pl
  #q$value <- q$value/10
  #pldf <- list(pl,q,q,pl)
  #genenames <- c("A","B","C","D")
  #xrange <- yrange <- c(0,20000)

  #pldf <- list(...)
  if(is.null(genenames) | length(pldf)!=length(genenames)){
    stop('provided number of gene names and plot data tables do not match\n')
  }
  if(!isTruthy(pldf[[1]]) | nrow(pldf[[1]])==0){
    return(NULL)
  }

  ## get range of values
  val.range <- c()
  nuniques <- c()
  uqvals <- c()
  for(i in 1:length(pldf)){
    pldf[[i]][,ycol] <- as.numeric(pldf[[i]][,ycol])
    if(log.transform==T){
      pldf[[i]][,ycol] <- log2(pldf[[i]][,ycol]+1)
    }
    val.range <- c(val.range,range(pldf[[i]][,ycol],na.rm=T))
    uqvals <- c(uqvals, unique(pldf[[i]][,ycol] ))
  }
  uqvals <- sort(unique(uqvals),decreasing = F)
  val.range <- range(val.range,na.rm = T)
  nuniques <- length(uqvals)
  pal <- grDevices::colorRampPalette(colScale)(nuniques)
  pal[1] <- minValCol
  coldf <- data.frame(val=uqvals,col=pal,stringsAsFactors = F)

  if(legendPlot==T){
    g <- data.frame(x=1,y=1,
                    z=seq(val.range[1],val.range[2],length.out = nuniques)
    )
    ax <- list(
      title = "",
      zeroline = FALSE,
      showline = FALSE,
      showticklabels = FALSE,
      showgrid = FALSE
    )

    p <- plot_ly(g,x=~x,y=~y,color = ~z,colors = pal,
                 type='scatter',mode='scatter') %>%
      layout(xaxis = ax, yaxis = ax) %>%
      colorbar(limits = val.range,yanchor='top',thickness=50,len=10,
               x=0,y=2,separatethousands=T,
               title=list(text=ycol,font=list(size=15))) %>%
      config(displayModeBar = F) %>%
      htmlwidgets::onRender("function(el,x){el.on('plotly_legendclick', function(){ return false; })}")
    return(p)

  }else{
    ## data subsetting
    if(!is.null(xrange)){
      for(i in 1:length(pldf)){
        g <- pldf[[i]]
        g <- subset(g, g[,x] >= xrange[1] &  g[,x] <= xrange[2] )
        pldf[[i]] <- g
        rm(g)
      }
    }
    if(!is.null(yrange)){
      for(i in 1:length(pldf)){
        g <- pldf[[i]]
        g <- subset(g, g[,y] >= yrange[1] &  g[,y] <= yrange[2] )
        pldf[[i]] <- g
        rm(g)
      }
    }

    ## make plot
    pllist <- list()
    for(i in 1:length(pldf)){
      gl <- pldf[[i]][,c(x,y,ycol)]
      names(gl) <- c("x","y","feature")
      gl$feature <- as.numeric(gl$feature)
      xx <- unique(gl$feature)
      xx <- coldf[coldf$val%in%xx,]
      xx <- xx[order(xx$val,decreasing = F),]

      p <- gl %>%
        rasterly::plotRasterly(aes(x=x,y=y,on=feature),
                     color=xx$col,
                     show_raster = T,drop_data = T,
                     as_image = T,variable_check = T,
                     plot_width = 300,plot_height = 300)

      pltitle <- list(
        text = genenames[i],
        font=list(size=18),
        yanchor = "bottom",
        xanchor = "center",
        align = "center",
        x = max(gl$x,na.rm = T)/2,
        y = max(gl$y,na.rm = T)*0.98,
        showarrow = FALSE
      )
      p$x$layoutAttrs[[1]]$xaxis$title <- "Z_coordinate_1"
      p$x$layoutAttrs[[1]]$yaxis$title <- "Z_coordinate_2"
      p <- p %>% layout(annotations = pltitle)
      pllist[[i]] <- p
      rm(gl)
    }

    rows = ceiling(length(pldf)/3)
    columns = ceiling(length(pldf)/rows)

    outplot <- subplot(pllist,nrows = rows,titleX = T,titleY = T) %>%
      config(displayModeBar = F)
    if(configlayout==T){
      outplot <- outplot %>%
        layout(height = (rows * 300), width = (columns * 300) )
    }

    return(outplot)
  }

}
