## These function are deprecated and no longer in use!

#' Function to plot gene epxression on 2D plot
#'
#' Function takes plot dataframe and other relevant parameters as input
#' @param pl data frame
#' @param x X-axis column name
#' @param y Y-axis column name
#' @param clustCol Name of the column carrying Cluster information
#' @param expnCol Name of the column carrying Expression values
#' @param feature Feature to be used to label the clusters
#' @param log2.transform Logical, if the expression column is to be log transformed
#' @param plot.ly Logical, whether to convert the plot to plotly
#' @import ggplot2
#' @import ggrepel
#' @import dplyr
#' @importFrom plotly ggplotly
#' @return ggplot2 object
#' @export
## color function
metafeatures.display.2D.sc <- function(pl=pl,x="V1",y="V2",clustCol="louvain",
                                       expnCol="value",feature="CellType",
                                       log2.transform=F,plot.ly=T){

  warning(' Deprecation alert: metafeatures.display.2D.sc\n')

  nexp <- which(names(pl)==expnCol)
  pl[,nexp] <- as.numeric(pl[,nexp])
  yy <- c(feature,clustCol)
  lc = pl %>%
    dplyr::group_by_at(feature) %>%
    dplyr::select(all_of(x),all_of(y)) %>%
    dplyr::summarize_all(c(mean,length))
  lc <- as.data.frame(lc)
  names(lc) <- c("SMTS","x","y","m1","m2")
  if(log2.transform==T){
    pl[,nexp] <- log2(pl[,nexp]+1)
  }
  psize = min(1321/nrow(pl),0.1)
  q <- ggplot(pl,aes(x = pl[,x], y = pl[,y],
                     text =paste0("</br> Source: ", pl[,feature],
                                  "</br> Value: ",pl[,expnCol])
  )) +
    geom_point(aes(col=pl[,nexp]),size=psize)+
    scale_color_gradient2(low="gray",mid="gray",high="blue")+
    #ggalt::geom_encircle(expand=0.0,aes(col=as.factor(louvain)))+
    ggrepel::geom_text_repel(aes(x = x,y = y,label = SMTS),size=2.5,data=lc,inherit.aes = F)+
    theme_bw()+
    theme(legend.position = "none",
          axis.text = element_blank(),
          axis.title = element_blank())

  if(plot.ly==T){
    q <- plotly::ggplotly(q,tooltip=c("text"))

  }
  return(q)

}


#' Function extracts our legend information from ggplot2 object
#'
#' takes ggplot2 input object to provide legend information.
#' The returned objected can be printed in a separate plot window
#' @param q ggplot2 object
#' @return legend
#' @import ggplot2
#' @export
ggplot_legend<-function(q){
  warning(' Deprecation alert: ggplot_legend\n')

  x <- ggplot_gtable(ggplot_build(q))
  leg <- which(sapply(x$grobs, function(i) i$name) == "guide-box")
  legend <- x$grobs[[leg]]
  legend
}


#' Function for plotting 2D representation of the samples and displaying metafeatures
#'
#' The function accepts the gene name and plot the locus using ggbio package
#' @param pl plot data frame with cluster assignment column
#' @param x  Column name containing X-axis values for the cluster point
#' @param y Column name containing Y-axis values for the cluster point
#' @param clustCol Column name that contains cluster assignment
#' @param expnCol Column name that contains expression values
#' @param feature Column name carrying features to be plotted on the 2D map. NULL behaviour plots cluster groups
#' @return A ggplot2 object
#' @import ggplot2
#' @import dplyr
#' @import ggrepel
#' @import data.table
#' @export
metafeatures.display.2D <- function(pl, x="V1",y="V2",clustCol="louvain",
                                    expnCol="value",
                                    feature=NULL){
  warning(' Deprecation alert: metafeatures.display.2D\n')

  .datatable.aware = TRUE
  nlou = which(names(pl)==clustCol)
  gg <- theme_bw()+
    theme(legend.position = "none",
          axis.text = element_text(size=14),
          axis.title = element_text(size=14),
          strip.text = element_text(size=14,face = 3),
          strip.background = element_blank(),
          plot.title = element_text(size=16,hjust=0.5),
          plot.subtitle = element_text(size=14,hjust=0.5))


  if(is.null(feature)){
    hc = pl %>%
      dplyr::group_by_at(clustCol) %>%
      dplyr::select(all_of(x),all_of(y)) %>%
      dplyr::summarize_all(mean)
    names(hc) <- c("id","x","y")

    cols <- NULL
    cols <- myCol.fun(k=length(unique(pl[,clustCol])))
    names(cols) <- sort(as.character(unique(pl[,clustCol])))
    nx = which(names(pl)==x)
    ny = which(names(pl)==y)

    wq <- pl %>%
      ggplot(aes(pl[,nx],pl[,ny],col=as.factor(pl[,nlou]),
                 text = paste0("</br> cluster: ",pl[,nlou])
      ))+
      geom_point(size=ifelse(length(unique(pl[,"SAMPID"])) <1000,5,1.2) )+
      ggtitle(paste0("cluster map"))+
      xlab("z_coordinate_1") + ylab("z_coordinate_2")+
      geom_density2d(col="gray",alpha=0.5)
    if(!is.null(cols)){
      wq <- wq + scale_color_manual(values = cols)
    }
    wq <- wq +
      ggrepel::geom_label_repel(aes(x=x,y=y,label = id),size=3.5,data=hc,inherit.aes = F)+
      gg

    return(wq)

  } else if(feature!="" & !is.null(feature)){
    yy <- c(feature,clustCol)
    if(feature == "expression"){
      nexp <- which(names(pl)==expnCol)
      wq <- pl %>%
        ggplot(aes(pl[,x],pl[,y],col=log2(pl[,nexp]+1)))+
        geom_point(size=ifelse(length(unique(pl[,"SAMPID"])) <1000,5,1.2) )+
        ggtitle(paste0("gene expression"))+
        xlab("z_coordinate_1")+
        ylab("z_coordinate_2")+
        geom_density2d(col="gray",alpha=0.5)+
        scale_color_gradient2(low="gray",mid="gray",high="blue")+
        gg
    }else{
      lc = pl %>%
        dplyr::group_by_at(yy) %>%
        dplyr::select(all_of(x),all_of(y)) %>%
        dplyr::summarize_all(c(mean,length))
      lc <- as.data.frame(lc)
      lc = data.table::data.table(lc)
      lc = lc[,mx:=max(V1_fn2),by=list(eval(get(clustCol))) ]
      lc = data.frame(lc)
      lc = lc[lc$V2_fn2==lc$mx,]
      lc$mx <- NULL
      lc = data.table::data.table(lc)
      names(lc)[1] <- "SMTS"
      lc = lc[,mx:=max(V1_fn2),by=list(SMTS)]
      names(lc) <- c("SMTS","id","x","y","m1","m2","m3")

      cols <- NULL
      cols <- myCol.fun(k=length(unique(pl[,feature])))
      if(!is.null(cols)){
        names(cols) <- sort(as.character(unique(pl[,feature])))
      }
      wq <-  tryCatch({
        q <- pl %>%
          ggplot(aes(pl[,x],pl[,y],col=as.factor(pl[,feature]) ))+
          geom_point(size=ifelse(length(unique(pl[,"SAMPID"])) <1000,5,1.2) )+
          ggtitle(paste0(feature))+xlab("z_coordinate_1")+
          ylab("z_coordinate_2")+
          geom_density2d(col="gray",alpha=0.5)+
          ggrepel::geom_label_repel(aes(x = x,y = y,col=SMTS,label = SMTS),
                                    size=3.5,data=lc,inherit.aes = F)+
          gg+
          theme(legend.position = "bottom",
                legend.title = element_blank())
        if(!is.null(cols)){
          q <- q + scale_color_manual(values = cols)
        }
        print(q)
        return(q)
      },
      error = function(e){
        q <- pl %>%
          ggplot(aes(pl[,x],pl[,y],col=as.factor(pl[,feature]) ))+
          geom_point(size=ifelse(length(unique(pl[,"SAMPID"])) <1000,5,1.2) )+
          ggtitle(paste0(feature))+
          xlab("z_coordinate_1")+
          ylab("z_coordinate_2")+
          geom_density2d(col="gray",alpha=0.5)+gg+
          theme(legend.position = "bottom",
                legend.title = element_blank())
        if(!is.null(cols)){
          q <- q + scale_color_manual(values = cols)
        }
        return(q)
      })
    }
    return(wq)
  }
}



#' Function retrieves the Expression dataframe for plotting (faster version)
#'
#' The function takes SQL connextion, gene of interest, the study and metaannotation features as input
#' @param conn Connection to the SQL database
#' @param genename GeneSymbol for retriving the expression values
#' @param study Selected study
#' @param metafeature metafeature column
#' @param groupContVars Continuous variables to group
#' @param nGroups Number of groups (default:5)
#' @param sms dataframe with sample metadata and cluster information
#' @return dataframe
#' @import RSQLite
#' @import data.table
#' @import dplyr
#' @export
get_plot_df01 <- function(conn,genename,study,metafeature,
                          groupContVars=NULL,nGroups=5,sms){

  warning(' Deprecation alert: get_plot_df01\n')

  idCol = which( colnames(sms)=="SAMPID" )
  query <- paste0("SELECT * FROM ",study,"_genes WHERE name = '",genename,"'")
  gdf <- RSQLite::dbGetQuery(conn, query)
  if(nrow(gdf)>0){
    gdf <- gdf[,c("gene_id","ObjID")] %>% unique
    fn1 <- function(x) paste0(x,collapse = ",")
    gdf <- gdf %>% dplyr::group_by(ObjID) %>% summarise_all(fn1)
    gdf <- as.data.frame(gdf)
    pl <- c()
    if(nrow(gdf)>0){
      for(i in 1:nrow(gdf)){
        if(is.na(gdf$ObjID[i])) { print(paste0("Error with gene",gdf$gene_id[i],"\n") ) }

        query <- paste0("SELECT SAMPID,", gdf$gene_id[i], " FROM ",study,"_subset",gdf$ObjID[i])
        qwe <- RSQLite::dbGetQuery(conn, query)
        qwe <- reshape::melt(qwe,measure.var=names(qwe)[2:ncol(qwe)] )
        if(sum(sms$SAMPID==qwe$SAMPID)==nrow(sms)){
          qwe <- cbind(qwe,sms[,-idCol] )
        }
        pl <- rbind(pl,qwe)
        rm(qwe)
      }
    }

    pl$logval <- log2(pl$value+1)

    if(!is.null(groupContVars)){
      for(cvar in groupContVars){
        if(cvar%in%names(pl)){
          x <- cut(pl[,cvar],breaks = nGroups,include.lowest = T) %>% as.character()
          x[is.na(x)] <- "Not available"
          pl[,cvar] <- gsub("\\[|\\]|\\(|\\)","",gsub(",","-",x))
          rm(x)
        }
      }
    }

  }else{
    pl <- as.data.frame(matrix(nrow = 0,ncol=(ncol(sms)+2+1) ))
    names(pl) <- c("SAMPID","variable","value",names(sms)[2:ncol(sms)],"logval")
  }
  return(pl)
}



#' Function retrieves dataframe to plot 2D represention of hte smaples for single cell data
#'
#' Function takes SQL connection, study and genename as input
#' @param connSc SQL connection
#' @param study study to use
#' @param genename gene name
#' @importFrom reshape melt
#' @importFrom RSQLite dbGetQuery
#' @import dplyr
#' @return dataframe
#' @export
## get dataframe for single cells
get_plot_df_sc <- function(connSc,study="Madissoon_GenomeBiol2020",
                           genename="WNT4"){

  warning(' Deprecation alert: get_plot_df_sc\n')

  query <- paste0("SELECT * FROM ",study,"_scRNASeq_genes WHERE geneSymbol = '",genename,"'")
  gdf <- RSQLite::dbGetQuery(connSc, query)
  query <- paste0("SELECT * FROM ",study,"_scRNASeq_metaFeatures")
  louvain <- RSQLite::dbGetQuery(connSc, query)

  if(nrow(gdf)>0){
    names(gdf) <- gsub("geneSymbol|GeneSymbol","name",names(gdf))
    gdf <- gdf[,c("name","ObjID")] %>% unique
    fn1 <- function(x) paste0(x,collapse = ",")
    gdf <- gdf %>% dplyr::group_by(ObjID) %>% summarise_all(fn1)
    gdf <- as.data.frame(gdf)
    pl <- c()
    if(nrow(gdf)>0){
      for(i in 1:nrow(gdf)){
        if(is.na(gdf$ObjID[i])) {
          print(paste0("Error with gene",gdf$name[i],"\n") )
        }
        query <- paste0("SELECT SAMPID,", gdf$name[i], " FROM ",study,"_scRNASeq_subset",gdf$ObjID[i])
        qwe <- RSQLite::dbGetQuery(connSc, query)
        qwe <- reshape::melt(qwe,measure.var=names(qwe)[2:ncol(qwe)] )
        pl <- rbind(pl,qwe)
        rm(qwe)
      }
    }
    pl$SAMPID <- gsub("[.]","-",pl$SAMPID)
    louvain$SAMPID <- gsub("[.]","-",louvain$SAMPID)
    pl <- merge(pl,louvain,by="SAMPID")

  }else{
    pl <- as.data.frame(matrix(nrow=0,ncol=(ncol(louvain)+2)  )    )
    names(pl) <- c("SAMPID","variable","value",names(louvain)[2:ncol(louvain)])
  }
  return(pl)
}


#' Function retrieves dataframe to plot 2D represention of hte smaples for single cell data (faster version)
#'
#' Function takes SQL connection, study and genename as input
#' @param connSc SQL connection
#' @param study study to use
#' @param genename gene name
#' @param louvain Data frame carrying sample metadata and cluster information
#' @importFrom reshape melt
#' @importFrom RSQLite dbGetQuery
#' @import dplyr
#' @return dataframe
#' @export
## get dataframe for single cells
get_plot_df_sc01 <- function(connSc,study="Madissoon_GenomeBiol2020",
                             genename="WNT4",louvain){

  warning(' Deprecation alert: get_plot_df_sc01\n')

  if(!'SAMPID'%in%names(louvain)){
    stop('Sample ID header should be SAMPID\n')
  }
  idCol = which( colnames(louvain)=="SAMPID" )

  query <- paste0("SELECT * FROM ",study,"_scRNASeq_genes WHERE geneSymbol = '",genename,"'")
  gdf <- RSQLite::dbGetQuery(connSc, query)

  if(nrow(gdf)>0){
    names(gdf) <- gsub("geneSymbol|GeneSymbol","name",names(gdf))
    gdf <- gdf[,c("name","ObjID")] %>% unique
    fn1 <- function(x) paste0(x,collapse = ",")
    gdf <- gdf %>% dplyr::group_by(ObjID) %>% summarise_all(fn1)
    gdf <- as.data.frame(gdf)
    pl <- c()
    if(nrow(gdf)>0){
      for(i in 1:nrow(gdf)){
        if(is.na(gdf$ObjID[i])) {
          print(paste0("Error with gene",gdf$name[i],"\n") )
        }
        query <- paste0("SELECT SAMPID,", gdf$name[i], " FROM ",study,"_scRNASeq_subset",gdf$ObjID[i])
        qwe <- RSQLite::dbGetQuery(connSc, query)
        qwe <- reshape::melt(qwe,measure.var=names(qwe)[2:ncol(qwe)] )
        if(sum(louvain$SAMPID==qwe$SAMPID)==nrow(louvain)){
          qwe <- cbind(qwe,louvain[,-idCol] )
        }
        pl <- rbind(pl,qwe)
        rm(qwe)
      }
    }
  }else{
    pl <- as.data.frame(matrix(nrow=0,ncol=(ncol(louvain)+2)  )    )
    names(pl) <- c("SAMPID","variable","value",names(louvain)[2:ncol(louvain)])
  }
  return(pl)
}


#' Function retrieves dataframe to plot 2D represention of hte smaples for single cell data (faster version-2)
#'
#' Function takes SQL connection, study and genename as input
#' @param connSc SQL connection
#' @param study study to use
#' @param genename gene name
#' @param louvain Data frame carrying sample metadata and cluster information
#' @importFrom reshape melt
#' @importFrom RSQLite dbGetQuery
#' @import dplyr
#' @return dataframe
#' @export
## get dataframe for single cells
get_plot_df_sc02 <- function(connSc,study="Madisson_LungTissue",
                             genename="WNT4",louvain){

  warning(' Deprecation alert: get_plot_df_sc02\n')


  if(!'SAMPID'%in%names(louvain)){
    stop('Sample ID header should be SAMPID\n')
  }
  idCol = which( colnames(louvain)=="SAMPID" )

  query <- paste0("SELECT * FROM ",study,"_genes WHERE geneSymbol = '",genename,"'")
  gdf <- RSQLite::dbGetQuery(connSc, query)

  if(nrow(gdf)>0){
    names(gdf) <- gsub("geneSymbol|GeneSymbol","name",names(gdf))
    gdf <- gdf[,c("name","ObjID")] %>% unique
    fn1 <- function(x) paste0(x,collapse = ",")
    gdf <- gdf %>% dplyr::group_by(ObjID) %>% summarise_all(fn1)
    gdf <- as.data.frame(gdf)
    pl <- c()
    if(nrow(gdf)>0){
      for(i in 1:nrow(gdf)){
        if(is.na(gdf$ObjID[i])) {
          print(paste0("Error with gene",gdf$name[i],"\n") )
        }
        query <- paste0("SELECT SAMPID,", gdf$name[i], " FROM ",study,"_subset",gdf$ObjID[i])
        qwe <- RSQLite::dbGetQuery(connSc, query)
        qwe <- reshape::melt(qwe,measure.var=names(qwe)[2:ncol(qwe)] )
        if(sum(louvain$SAMPID==qwe$SAMPID)==nrow(louvain)){
          qwe <- cbind(qwe,louvain[,-idCol] )
        }
        pl <- rbind(pl,qwe)
        rm(qwe)
      }
    }
  }else{
    pl <- as.data.frame(matrix(nrow=0,ncol=(ncol(louvain)+2)  )    )
    names(pl) <- c("SAMPID","variable","value",names(louvain)[2:ncol(louvain)])
  }
  return(pl)
}

#' Function retrieves the Expression dataframe for plotting
#'
#' The function takes SQL connextion, gene of interest, the study and metaannotation features as input
#' @param conn Connection to the SQL database
#' @param genename GeneSymbol for retriving the expression values
#' @param study Selected study
#' @param metafeaure metafeatures to be used for sorting the X-axis labels
#' @param sortoption How to sort the data e.g. sample_name, median_value
#' @param groupContVars Continuous variables to group
#' @param nGroups Number of groups (default:5)
#' @return dataframe
#' @import RSQLite
#' @import data.table
#' @import dplyr
#' @export
get_plot_df <- function(conn,genename,study,metafeature,
                        sortoption="sample_name",groupContVars=NULL,
                        nGroups=5){

  warning(' Deprecation alert: get_plot_df\n')


  query <- paste0("SELECT * FROM ",study,"_genes WHERE name = '",genename,"'")
  gdf <- RSQLite::dbGetQuery(conn, query)

  query <- paste0("SELECT * FROM ",study,"_samples")
  sms <- RSQLite::dbGetQuery(conn, query)
  query <- paste0("SELECT * FROM ",study,"_scvis")
  louvain <- RSQLite::dbGetQuery(conn, query)

  if(nrow(gdf)>0){
    gdf <- gdf[,c("gene_id","ObjID")] %>% unique
    fn1 <- function(x) paste0(x,collapse = ",")
    gdf <- gdf %>% dplyr::group_by(ObjID) %>% summarise_all(fn1)
    gdf <- as.data.frame(gdf)
    pl <- c()
    if(nrow(gdf)>0){
      for(i in 1:nrow(gdf)){
        if(is.na(gdf$ObjID[i])) { print(paste0("Error with gene",gdf$gene_id[i],"\n") ) }

        query <- paste0("SELECT SAMPID,", gdf$gene_id[i], " FROM ",study,"_subset",gdf$ObjID[i])
        qwe <- RSQLite::dbGetQuery(conn, query)
        qwe <- reshape::melt(qwe,measure.var=names(qwe)[2:ncol(qwe)] )
        pl <- rbind(pl,qwe)
        rm(qwe)
      }
    }
    pl <- merge(pl,sms,by="SAMPID")
    louvain[,names(sms)[names(sms)!="SAMPID"]] <- NULL
    pl <- merge(pl,louvain,by="SAMPID")
    pl$logval <- log2(pl$value+1)

    if(!is.null(groupContVars)){
      for(cvar in groupContVars){
        if(cvar%in%names(pl)){
          x <- cut(pl[,cvar],breaks = nGroups,include.lowest = T) %>% as.character()
          x[is.na(x)] <- "Not available"
          pl[,cvar] <- gsub("\\[|\\]|\\(|\\)","",gsub(",","-",x))
          rm(x)
        }
      }
    }
    if(sortoption=="median_value"){
      mdexp = pl %>%
        dplyr::group_by_at(metafeature) %>% dplyr::select(value) %>%
        dplyr::summarize_all(median)
      mdexp = mdexp[order(mdexp$value,decreasing = F),]
      mdexp = as.data.frame(mdexp)
      pl[,metafeature] <- factor(pl[,metafeature],levels=mdexp[,metafeature])
    }

  }else{

    pl <- as.data.frame(matrix(nrow = 0,ncol=(ncol(louvain)+ncol(sms)-1+2+1) ))
    names(pl) <- c("SAMPID","variable","value",names(sms)[2:ncol(sms)],
                   names(louvain)[2:ncol(louvain)],"logval")
  }
  return(pl)

}


