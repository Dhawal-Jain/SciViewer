


#' Function to provide color scales in low,mid,max format, additional minimum value color is specified
#'
#' The returned object is list
#' @param option option for hte colorscale i.e. GrayBlue,Clay,Viridis,GreenYellow,Purple,Reds,Organges
#' @return list of colors
#' @export
## color scale list
select_colScale <- function(option=NULL){
  colScale <- NULL
  minValCol <- NULL
  
  if(is.null(option) | option=='GrayBlue'){
    colScale <- c("#fcfbfd", "#9e9ac8", "#3f007d")
    minValCol <- "#f0f0f0"    
  }else if(option=='Clay'){
    colScale <- c("#f3b071","#c66810", "#472100")
    minValCol <- "#f6c292"    
  }else if(option=='Viridis'){
    colScale <- c("#dce319ff","#238a8dff", "#440154ff")
    minValCol <- "#fde725ff"    
  }else if(option=='GreenYellow'){
    colScale <- c("#f7fcb9","#78c679", "#004529")
    minValCol <- "#ffffe5"    
  }else if(option=='Purple'){
    colScale <- c("#e0ecf4","#8c96c6", "#4d004b")
    minValCol <- "#f7fcfd"    
  }else if(option=='Reds'){
    colScale <- c( "#fee0d2","#fb6a4a", "#67000d")
    minValCol <- "#fff5f0"    
  }else if(option=='Oranges'){
    colScale <- c("#fee8c8","#fc8d59", "#7f0000")
    minValCol <- "#fff7ec"    
  } 
  
  return(list(A=colScale,B=minValCol))
}



#' Function to provide interactivity on plotly plot
#'
#' The returned object is list
#' @param zoom zoom is an input graph-based dataframe
#' @return list of values
#' @export
## zoom values
getZoomrange <- function(zoom){
  if(!is.null(zoom)){
    #zoom <- event_data("plotly_relayout", source = source.val)
    xr <- NULL
    yr <- NULL
    if(is.null(zoom) || names(zoom[1]) %in% c("xaxis.autorange", "width")) {
    } else {
      xr <- c(zoom$`xaxis.range[0]`,zoom$`xaxis.range[1]`)
    }
    if(is.null(zoom) || names(zoom[1]) %in% c("yaxis.autorange", "width")) {
    } else {
      yr <- c(zoom$`yaxis.range[0]`,zoom$`yaxis.range[1]`)
    }
    return(list(xr,yr))
  }else{
    return(list(A=c(NULL,NULL),B=c(NULL,NULL)))
  }
}



#' Function to provide hover coordinates from the plotly object
#'
#' The returned object an HTML tag
#' @param pl dataframe used for providing hover coordinates
#' @param colids column names of the dataframe used for preparing HTML tag
#' @param hovercoord coordinates for the hover position
#' @return HTML tag
#' @export
## HTML tag
getHoverText <- function(pl,colids = c('V1','V2','cell_type'),hovercoord = NULL){
  out <- ""
  if(length(colids)<3 | is.null(hovercoord)){
    return(out)
  }
  
  gl <- pl[,colids]
  #hc <- floor(hovercoord)
  hc <- (hovercoord)
  upper = 1.02
  lower = 0.98
  g <- NULL
  r1 <- sort(c(hc[1]*upper,hc[1]*lower),decreasing = F)
  r2 <- sort(c(hc[2]*upper,hc[2]*lower),decreasing = F)
  
  if(!is.null(hovercoord)){
    gl <- gl[ gl[,colids[1]] <= r1[2], ]
    gl <- gl[ gl[,colids[1]] >= r1[1], ]
    gl <- gl[ gl[,colids[2]] <= r2[2], ]
    gl <- gl[ gl[,colids[2]] >= r2[1], ]
    gl <- unique(gl)
    x <- names(sort(table(unique(gl[,colids[3]])),decreasing = T))[1]
    g <- c(hc,x)
  }
  
  if(!is.null(g[3])){
    out <- paste0("<style> border-style:solid; border-color:\"#287EC7\";</style>
                   <font color=\"#000000\"><background-color=\"#99FFFF\">
                   <b> Z_coordinate_1: </b>", g[1] ,"<br>
                   <b> Z_coordinate_2: </b>", g[2] ,"<br>
                   <b>",colids[3],": </b>", g[3] ,"<br>")
  }
  out
  
}





#' Function to plot multi-gene grouped heatmap and dotplot 
#'
#' the function takes range of input parameters to draw interactive high-density multi-gene heatmap/ dotplots 
#' The returned object is a list of plotly object
#' @param pldf List of dataframes per gene, used for making multiple plots
#' @param genenames names of the genes corresponding to the pldf names
#' @param feature feature for grouping the data
#' @param x x-axis column name (default: V1)
#' @param y y-axis column name (default: V2)
#' @param ycol value to be used for projection on the plot
#' @param xrange range of x-axis values for subsetting the datasets
#' @param yrange range of y-axis values for subsetting the datasets
#' @param log.transform logical, whether to perform log transformation on the data (default:F)
#' @param colScale color scale used for projection, a set of 3 colors min,mid,max
#' @param minValCol color used for the lowest value 
#' @import ggplot2
#' @import dplyr
#' @importFrom plotly ggplotly
#' @importFrom heatmaply heatmaply
#' @return list of plotly plot object
#' @export
## list of plotly plot objects
plot_multigene_grouped_heatmap <- function(pldf,genenames=NULL,
                                           feature,
                                           x='V1',y='V2',ycol='value',
                                           xrange=NULL, yrange=NULL,
                                           log.transform=F,
                                           colScale=c("#fcfbfd", "#9e9ac8", "#3f007d"),
                                           minValCol="#f0f0f0"){
  #pldf <- list(...)
  if(is.null(genenames) | length(pldf)!=length(genenames)){
    stop('provided number of gene names and plot data tables do not match\n')
  }
  
  ## data subsetting
  if(!is.null(xrange)){
    for(i in 1:length(pldf)){
      g <- pldf[[i]]
      g <- subset(g, g[,x] >= xrange[1] &  g[,x] <= xrange[2] )
      pldf[[i]] <- g
      rm(g)
    }
  }
  if(!is.null(yrange)){
    for(i in 1:length(pldf)){
      g <- pldf[[i]]
      g <- subset(g, g[,y] >= yrange[1] &  g[,y] <= yrange[2] )
      pldf[[i]] <- g
      rm(g)
    }
  }
  
  ## whether to transform the data
  if(log.transform==T){
    for(i in 1:length(pldf)){
      pldf[[i]][,ycol] <- as.numeric(pldf[[i]][,ycol])
      pldf[[i]][,ycol] <- log2(pldf[[i]][,ycol]+1)
    }
  }
  
  ## create plot data.frame
  pl <- c()
  for(i in 1:length(pldf)){
    funx <- function(x){ length(x[x!=0])  }
    z <- pldf[[i]] %>%
      dplyr::group_by_at(feature) %>% dplyr::select(dplyr::all_of(ycol)) %>%
      dplyr::summarise_all(c(mean,length,funx))
    
    z <- as.data.frame(z)
    names(z) <- c("group","average",'count','expnperc')
    z$name <- genenames[i]
    pl <- rbind(pl,z)
    rm(z)
  }
  pl$expnperc <- round(pl$expnperc*100/pl$count,3)
  
  pal <- grDevices::colorRampPalette(colScale)(length(unique(pl$average)))
  pal[1] <- minValCol
  require(heatmaply)
  z <- reshape2::dcast(pl,group~name,value.var = 'average')
  rownames(z) <- z$group
  z$group <- NULL
  
  if(ncol(z)>1){
    z <- apply(z,1,function(x){
      x <- x*100/sum(x)
      #x <- (x -mean(x))/sd(x)
      x <- ifelse(!is.finite(x),0,x)
      return(x)
    }) %>% t %>% as.data.frame
  }
  
  ## heatmap
  heat <- heatmaply::heatmaply(z,colors = pal,Colv =  NULL,
                               show_dendrogram = c(T,F))
  
  ## plotly
  o <- heat[["x"]][["data"]][[1]][["text"]][,1]
  o <- gsub("<br>.*$","",gsub("row: ","",o))
  pl$group <- factor(pl$group,levels=o)
  rows <- min(c(800,ceiling(nrow(pl)/50) * 400))
  columns <- min(c(800,ceiling(ncol(pl)/2) * 200))
  
  P <- ggplot(pl,aes(x=name,y=group,col=average,size=expnperc,
                     text=paste0('Gene: ',name,'<br>',
                                 'Cell type: ',group, '<br>',
                                 'Expression: ', formatC(average,digits = 2,format = 'e'),'<br>',
                                 'Cell count: ', count,'<br>',
                                 '%Cell Expressing: ', expnperc,'<br>')
  ))+
    geom_point()+
    theme(axis.text.x = element_text(color='black',angle = 45,hjust = 0.5))+
    scale_color_gradient2(limits=range(pl$average,na.rm = T),
                          low = '#ffffe5',mid = '#78c679',high = '#004529',
                          space = 'Lab')+
    theme_bw() + xlab("") +ylab("")
  P <- P + labs(color="normalized \nexpression")
  P <- P %>% ggplotly(tooltip = 'text')
  P <- P %>% layout(width=columns,height = rows)
  
  plotlist <- list(heat,P)
  
  return(plotlist)
  
}


#' Function to plot grouped violin plot 
#'
#' the function takes range of input parameters to draw interactive grouped violin plot 
#' The returned object is a plotly object
#' @param pldf List of dataframes per gene, used for making multiple  plots
#' @param genenames names of the genes corresponding to the pldf names
#' @param feature feature for grouping the data
#' @param x x-axis column name (default: V1)
#' @param y y-axis column name (default: V2)
#' @param ycol value to be used for projection on the plot
#' @param xlab x-axis label
#' @param ylab y-axis label
#' @param main plot title
#' @param xrange range of x-axis values for subsetting the datasets
#' @param yrange range of y-axis values for subsetting the datasets
#' @param log.transform logical, whether to perform log transformation on the data (default:F)
#' @import ggplot2
#' @import dplyr
#' @importFrom plotly ggplotly
#' @return list of plotly plot object
#' @export
## plotly plot object with grouped violins
plot_grouped_violin <- function(pldf,genenames=NULL,
                                feature,
                                x='V1',y='V2',ycol='value',
                                xlab="",ylab="",
                                main='expression summary',
                                xrange=NULL, yrange=NULL,
                                log.transform=F){
  #pldf <- list(...)
  if(is.null(genenames) | length(pldf)!=length(genenames)){
    stop('provided number of gene names and plot data tables do not match\n')
  }
  
  ## allow only 3 groups per x-value
  if(length(genenames)>3){
    pldf <- pldf[1:3]
    genenames <- genenames[1:3]
  }
  
  ## data subsetting
  if(!is.null(xrange)){
    for(i in 1:length(pldf)){
      g <- pldf[[i]]
      g <- subset(g, g[,x] >= xrange[1] &  g[,x] <= xrange[2] )
      pldf[[i]] <- g
      rm(g)
    }
  }
  if(!is.null(yrange)){
    for(i in 1:length(pldf)){
      g <- pldf[[i]]
      g <- subset(g, g[,y] >= yrange[1] &  g[,y] <= yrange[2] )
      pldf[[i]] <- g
      rm(g)
    }
  }
  
  nvars <- pldf[[1]][,feature] %>% unique() %>% length()
  if(nvars>50){
    pblnk <- plotly_empty() %>%
      layout(width=10,height=10)
    return(pblnk)
  }
  
  
  ## create plot data.frame
  cf <- c()
  for(i in 1:length(pldf)){
    cf <- rbind(cf,data.frame(name=genenames[i],
                              grp=pldf[[i]][,feature],
                              val=pldf[[i]][,ycol])
    )
  }
  
  cols <- pddExpn::myCol.fun(k = length(unique(cf$name)))
  if(is.null(cols)){
    cols <- pddExpn::myCol.fun(k = 42)
    cols <- rep(cols,10)[1:length(unique(cf$name))]
    if(is.null(cols)){
      cols='gray'
    }
  }
  
  rows <- 450
  columns <- max(c(ceiling(nvars) * length(genenames) * 15,800))
  q <- pddExpn::plot.violin(features = c('grp','name'),
                            ycol = 'val',pl = cf,
                            main = main,xlab=xlab,ylab=ylab,
                            plot.ly = T,log.transform = log.transform)
  q <- q %>% layout(height=rows,width=columns,
                    xaxis = list(tickangle = 45))
  return(q)
}



#' Function to plot differential expression dot plot 
#'
#' the function takes range of input parameters to draw interactive differential expression dot plot  
#' The returned object is a plotly object
#' @param pl input dataframe
#' @param x x-axis value
#' @param y y-axis value
#' @param colCol column to be used for color
#' @param sizeCol column to be used for size of the points
#' @param testCol column to be used for Test
#' @param configlayout logical, whether to configure plot layout
#' @import ggplot2
#' @import dplyr
#' @importFrom plotly ggplotly
#' @return a plotly plot object
#' @export
## plotly plot object 
sc_dge_dotplot <- function(pl, x='geneSymbol',y='Tag',
                           colCol='logFC',sizeCol='adj.P.Val',
                           testCol='Test',configlayout=T){
  if(!isTruthy(pl) | nrow(pl)==0){
    return(NULL)
  }
  gl <- pl[,c(x,y,colCol,sizeCol,testCol)]
  names(gl) <- c('geneSymbol','Tag','logFC','adj.P.Val','Test')
  
  rows <- min(c(900, ceiling(length(unique(gl$Tag))/40)  * 400))
  columns <- min(c(800,length(unique(gl$geneSymbol)) * 300 ))
  
  P <- ggplot(gl,aes(x=geneSymbol,y=Tag,col=logFC,
                     size=-log10(adj.P.Val),
                     text=paste0('Gene: ',geneSymbol,'<br>',
                                 'Cell type: ',Tag, '<br>',
                                 'FDR: ', formatC(adj.P.Val,digits = 2,format = 'e'),'<br>',
                                 'Log2FC: ', round(logFC,2),'<br>',
                                 'Test: ', Test,'<br>')
  ))+geom_point()+
    scale_color_gradient2(limits=range(gl$logFC,na.rm = T),
                          low = '#542788',mid = '#f7f7f7',high = '#b35806',
                          space = 'Lab')+
    theme_bw() + xlab("") +ylab("")+
    theme(axis.text.x = element_text(color='black',angle = 45,hjust = 0.5))
  
  P <- P + labs(color="logFC")
  P <- P %>% ggplotly(tooltip = 'text')
  
  if(configlayout==T){
    P <- P %>% layout(width=columns,height = rows)
  }
  
  return(P)
}



#' Function to plot volcano plot 
#'
#' the function takes range of input parameters to draw interactive volcano plot  
#' The returned object is a plotly object
#' @param pl input dataframe
#' @param x x-axis value
#' @param y y-axis value
#' @param colCol column to be used for color
#' @param sizeCol column to be used for size of the points
#' @param testCol column to be used for Test
#' @param configlayout logical, whether to configure plot layout
#' @import ggplot2
#' @import dplyr
#' @importFrom plotly ggplotly
#' @return a plotly plot object
#' @export
## plotly plot object 
sc_dge_volcanoplot <- function(pl, x='geneSymbol',y='Tag',
                               colCol='logFC',sizeCol='adj.P.Val',
                               testCol='Test',main=""){
  if(!isTruthy(pl) | nrow(pl)==0){
    return(NULL)
  }
  gl <- pl[,c(x,y,colCol,sizeCol,testCol)]
  names(gl) <- c('geneSymbol','Tag','logFC','adj.P.Val','Test')
  
  P <- ggplot(gl,aes(x=logFC,y=-log10(adj.P.Val),col=logFC,
                     #size=-log10(adj.P.Val),
                     text=paste0('Gene: ',geneSymbol,'<br>',
                                 'Cell type: ',Tag, '<br>',
                                 'FDR: ', formatC(adj.P.Val,digits = 2,format = 'e'),'<br>',
                                 'Log2FC: ', round(logFC,2),'<br>',
                                 'Test: ', Test,'<br>')
  ))+geom_point()+
    geom_hline(yintercept =1.3,col='#31a354',linetype='dashed' )+
    geom_vline(xintercept =c(-1,1),col='#31a354',linetype='dashed' )+
    scale_color_gradient2(limits=range(gl$logFC,na.rm = T),
                          low = '#542788',mid = '#f7f7f7',high = '#b35806',
                          space = 'Lab')+
    theme_bw() + xlab("logFC") +ylab("-log10(FDR)")+
    ggtitle(label = main)+
    theme(axis.text.x = element_text(color='black',angle = 0,hjust = 0.5),
          legend.position = 'right',
          plot.title = element_text(size=15,hjust = 0.5,colour = 'black'))
  
  P <- P + labs(color="")
  P <- P %>% ggplotly(tooltip = 'text')
  
  return(P)
  
}





