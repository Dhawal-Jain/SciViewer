
# basic statistics functions


#' Function to calculate geometric mean
#'
#' Takes numeric vector as an input and calcualte geometric mean
#' @param x Numeric vector
#' @return geometric mean
#' @export
gmean <- function(x, na.rm=TRUE){
  exp(sum(log(x), na.rm=na.rm) / length(x))
}


#' Function to calculate standard error of the mean
#'
#' Takes numeric vector as an input and calcualte standar error of the mean
#' @param x Numeric vector
#' @return standard error of the mean
#' @export
sem <- function(x){
  if(length(x)<3){
    return(0)
  }else{
    return(sd(x, na.rm=TRUE) /  sqrt(length(x[!is.na(x)])))
  }
}




