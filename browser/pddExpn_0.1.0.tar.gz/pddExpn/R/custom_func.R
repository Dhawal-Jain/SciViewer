## This file contains custom functions


#' Function summarizes given column of the data frame using multiple features
#'
#' Takes dataframe and feature list as input
#' the returned object is a summary dataframe
#' requires dplyr package
#' @param features character vector of features used for grouping
#' @param sumcol Column to be used for summarizing
#' @param pl data frame where column names contain variables listed in features vector
#' @return dataframe
#' @import dplyr
#' @export
summarytable <- function(features,sumcol="logval",pl){
  #features <- c("variable",features)
  if(length(features)!=sum(features%in%colnames(pl))){
    stop(" Error! Features are not present in the provided data frame\n")
  }else{
    dat <- pl %>% dplyr::group_by_at(features) %>% dplyr::select(all_of(sumcol)) %>%
      dplyr::summarise_all(c(mean,sd,sem))
    #names(dat)[1] <- "gene_id"
    names(dat) <- gsub("fn1","average",names(dat))
    names(dat) <- gsub("fn2","standard deviation",names(dat))
    names(dat) <- gsub("fn3","standard error of the mean",names(dat))
    return(dat)
  }
}


#' Function retrieves the Expression dataframe for plotting (faster version)
#'
#' The function takes SQL connextion, gene of interest, the study and metaannotation features as input
#' @param conn Connection to the SQL database
#' @param genename GeneSymbol for retriving the expression values
#' @param study Selected study
#' @param groupContVars Continuous variables to group
#' @param nGroups Number of groups (default:5)
#' @param louvain dataframe with sample metadata and cluster information
#' @param colVar variable used for colorscaling (default: gene_id)
#' @param geneSymbolVar Gene Symbol variable (default: geneSymbolVar)
#' @return dataframe
#' @import RSQLite
#' @import data.table
#' @import dplyr
#' @export
get_plot_df_v1 <- function(conn,genename,study,
                           groupContVars=NULL,nGroups=5,louvain,
                           colVar='gene_id',geneSymbolVar='name'){

  query <- paste0("SELECT * FROM ",study,"_genes WHERE ",geneSymbolVar," = '",genename,"'")
  gdf <- RSQLite::dbGetQuery(conn, query)

  if(nrow(gdf)>0){
    gdf <- gdf[,c(colVar,"ObjID")] %>% unique
    names(gdf)[1]<- 'IDx'
    pl <- c()
    for(i in 1:nrow(gdf)){
      query <- paste0("SELECT SAMPID,", gdf$IDx[i], " FROM ",study,"_subset",gdf$ObjID[i])
      qwe <- RSQLite::dbGetQuery(conn, query)
      qwe <- reshape::melt(qwe,measure.var=names(qwe)[2:ncol(qwe)] )
      pl <- rbind(pl,qwe)
      rm(qwe)
    }
    names(pl)[2] = colVar
    louvain <- louvain[match(pl$SAMPID,louvain$SAMPID),]
    if(sum(louvain$SAMPID==pl$SAMPID)!=nrow(pl)){
      stop('Error in generating plot data frmae\n')
    }
    pl$SAMPID <- NULL
    pl <- cbind(louvain,pl)
    if(!is.null(groupContVars)){
      for(cvar in groupContVars){
        if(cvar%in%names(pl)){
          x <- cut(pl[,cvar],breaks = nGroups,include.lowest = T) %>% as.character()
          x[is.na(x)] <- "Not available"
          pl[,cvar] <- gsub("\\[|\\]|\\(|\\)","",gsub(",","-",x))
          rm(x)
        }
      }
    }
  }else{
    pl <- as.data.frame(matrix(nrow = 0,ncol=(ncol(louvain)+2) ))
    names(pl) <- c(names(louvain),colVar,'value')
  }
  return(pl)
}


#' Function retrieves dataframe to plot 2D represention of hte smaples for single cell data (faster version-3)
#'
#' Function takes SQL connection, study and genename as input
#' @param connSc SQL connection
#' @param study study to use
#' @param genename gene name
#' @param louvain Data frame carrying sample metadata and cluster information
#' @importFrom reshape melt
#' @importFrom RSQLite dbGetQuery
#' @import dplyr
#' @return dataframe
#' @export
## get dataframe for single cells
get_plot_df_sc03 <- function(connSc,study="Madisson_LungTissue",
                             genename="WNT4",louvain){
  #louvain must have a value column
  if(!'value'%in%names(louvain)){
    louvain$value <- 0
  }

  query <- paste0("SELECT * FROM ",study,"_data WHERE geneSymbol = '", genename,"'")
  gdf <- RSQLite::dbGetQuery(connSc, query)
  if(nrow(gdf)>0){
    cnta <- matrix(0,nrow = nrow(louvain),ncol=nrow(gdf)) %>% as.data.frame
    for(i in 1:nrow(gdf)){
      gdfa <- data.frame(col_index= as.numeric(unlist(strsplit(gdf[i,]$col_index,","))),
                         value = as.numeric(unlist(strsplit(gdf[i,]$value,","))))
      gdfa <- gdfa[order(gdfa$col_index,decreasing = F),]
      cnta[gdfa$col_index,i] <- gdfa$value
      rm(gdfa,i)
    }
    if(ncol(cnta)>1){
      cnta <- rowMeans(cnta)
    }else{
      cnta <- cnta$V1
    }
    louvain$value <- cnta
  }else{
    louvain <- louvain[0,]
  }

  return(louvain)
}


#' Function retrieves dataframe to plot DEG and Variance Partition
#'
#' Function takes SQL connection, study and genename as input
#' @param conn SQL connection
#' @param study study to use
#' @param genename gene name
#' @param metafeaure metafeatures to be used for sorting the X-axis labels
#' @param add.grp.var value of grouping variable (default NULL)
#' @param filt.genes genes to be filtered out, default is NULL
#' @importFrom reshape melt
#' @importFrom RSQLite dbGetQuery
#' @return dataframe
#' @export
## get dataframe for DEG and VarPart
get_DEplot_dfs <- function(conn,genename,study,metafeature="COPD",
                           add.grp.var=NULL,filt.genes=NULL){

  if(is.null(add.grp.var)){
    vpg <- as.data.frame(matrix(NA,nrow = 0,ncol = 4) )
    names(vpg) <- c("gene_id","Var1","variable","value")
    deg <- as.data.frame(matrix(NA,nrow = 0,ncol = 10) )
    names(deg) <- c("Var1", "gene_id", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val",
                    "B", "Test", "log10_Pval")
    vpout <- as.data.frame(matrix(NA,nrow = 0,ncol = 7) )
    names(vpout) <- c("gene_id", "Var1", metafeature, "name", "Rank", "Total", "label")
    vpout1 <- as.data.frame(matrix(NA,nrow = 0,ncol = 7) )
    names(vpout1) <- c("gene_id", "Var1", metafeature, "name", "Rank", "Total", "label")
  }else{
    vpg <- as.data.frame(matrix(NA,nrow = 0,ncol = 5) )
    names(vpg) <- c("gene_id",add.grp.var,"Var1","variable","value")
    deg <- as.data.frame(matrix(NA,nrow = 0,ncol = 11) )
    names(deg) <- c("Var1", "gene_id", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val",
                    "B", "Test",add.grp.var, "log10_Pval")
    vpout <- as.data.frame(matrix(NA,nrow = 0,ncol = 8) )
    names(vpout) <- c("gene_id", "Var1", metafeature,add.grp.var, "name", "Rank", "Total", "label")
    vpout1 <- as.data.frame(matrix(NA,nrow = 0,ncol = 8) )
    names(vpout1) <- c("gene_id", "Var1", metafeature,add.grp.var, "name", "Rank", "Total", "label")
  }
  #gene_id='ENSG00000233927'
  #metafeature = 'COPD'
  #query <- paste0("SELECT * FROM ",study,"_VarPartVoomPartial")

  ##--- genes
  query <- paste0("SELECT gene_id, name FROM ",study,"_genes")
  genes <- RSQLite::dbGetQuery(conn, query)
  gene_id = genes[genes$name==genename,]$gene_id %>%
    as.character() %>% unique()
  if(length(gene_id)>1){
    gene_id = gene_id[1]
  }
  if(length(gene_id)==0){
    return(list(DEG=deg,VP=vpout,VPLab=vpout1,VPG=vpg))
  }

  ##-- vp/vpg
  if(is.null(add.grp.var)){
    query <- paste0("SELECT gene_id,Var1,",metafeature," FROM ",study,"_VarPartVoomPartial")
  }else{
    query <- paste0("SELECT gene_id,Var1,",metafeature,",", add.grp.var," FROM ",study,"_VarPartVoomPartial")
  }
  vp <- RSQLite::dbGetQuery(conn, query)
  query <- paste0("SELECT * FROM ",study,"_VarPartVoomPartial WHERE gene_id = '",gene_id,"'  " )
  vpg <- RSQLite::dbGetQuery(conn, query)
  if(nrow(vpg)>0){
    vpg <- reshape::melt(vpg,
                         measure.vars=names(vpg)[!names(vpg)%in%c("gene_id",add.grp.var,"Var1")] )
  }
  query <- paste0("SELECT * FROM ",study,"_LimmaSVADEGPartial WHERE gene_id = '",gene_id,"'  " )
  deg <- RSQLite::dbGetQuery(conn, query)
  deg$log10_Pval <- -log10(deg$P.Value)

  vp <- merge(vp,unique(genes),by="gene_id",all.x=T)

  #head(vp)
  vp$name <- ifelse(is.na(vp$name),as.character(vp$gene_id),as.character(vp$name))
  vp <- split(vp,f = vp$Var1)
  vpout <- c()
  for(i in 1:length(vp)){
    qw <- vp[[i]]
    qw$Rank <- rank(qw[,metafeature],ties.method = "first")
    qw$Total <- nrow(qw)
    qw$Rank <- max(qw$Rank)-qw$Rank +1
    qw <- qw[order(qw$Rank,decreasing = F),]
    qw$label <- paste0(qw$name," (", round(qw[,metafeature]*100, 1),"%)")
    qw$label <- ifelse(qw$gene_id%in% c(qw$gene_id[1:5],gene_id),as.character(qw$label),NA  )
    vpout <- rbind(vpout,qw)
    rm(qw,i)
  }
  vpout1 <- vpout[!is.na(vpout$label),]

  if(!is.null(filt.genes)){
    vpout <- vpout[!vpout$gene_id%in%filt.genes,]
    vpout1 <- vpout1[!vpout1$gene_id%in%filt.genes,]
  }

  return(list(DEG=deg,VP=vpout,VPLab=vpout1,VPG=vpg))
}

#' Function to round up the numeric values in the dataframe
#'
#' @param df data.frame
#' @param digits digits to round up to, default2
#' @return dataframe
#' @export
round_df <- function(df, digits=2) {
  nums <- vapply(df, is.numeric, FUN.VALUE = logical(1))
  df[,nums] <- round(df[,nums], digits = digits)
  df
}


#' Function to generate random string
#'
#' @param n number of random strings to generate
#' @param length The length of each string, default: 12
#' @return vector of strings
#' @export
randomStringGenerator <- function(n=1, lenght=12){
  randomString <- c(1:n)                  # initialize vector
  for (i in 1:n){
    randomString[i] <- paste(sample(c(0:9, letters, LETTERS),
                                    lenght, replace=TRUE),
                             collapse="")
  }
  return(randomString)
}



#' Function to generate TPM normalized count table
#'
#' @param cnt data.frame with raw counts
#' @param genes data frame with gene information, columns must be gene_id name len and gene_id should be the rownames of cnt
#' @return dataframe
#' @export
## get dataframe for DEG and VarPart
tpm.normalize <- function(cnt,genes){
  ## cnt : data frame with ENSEMBL gene_id as rownames and samples as columns
  ## genes has 3 columns: gene_id, name, len
  ids <- rownames(cnt)
  cnt <- data.frame(lapply(cnt,as.numeric))
  rownames(cnt) <- ids

  genes <- genes[genes$gene_id%in%rownames(cnt),]
  cnt <- cnt[rownames(cnt)%in%genes$gene_id,]

  cnt <- cnt[match(genes$gene_id,rownames(cnt)),]
  if(sum(rownames(cnt)==genes$gene_id) == nrow(cnt)){
    cat("numer of genes in the normalization ", nrow(cnt),"\n")
  }else{
    stop("error in mapping gene ids to their respective lengths\n")
  }

  #rownames(cnt)==genes$gene_id

  cnt <- cnt*1000/genes$len
  cnt <- apply(cnt,2,function(x){
    round((x*1e6)/sum(x),2)
  })
  cnt <- cnt[rowSums(cnt)>0,]
  cnt <- as.data.frame(cnt)
  cnt <- unique(cnt)
  cnt
}


#' Function to cluster the data using Louvain modularity approac
#'
#' @param pl dataframe
#' @param xcoord column name with X coordinate
#' @param ycoord column name with Y coordinate
#' @param k number of bootstrap
#' @import FNN
#' @import igraph
#' @return dataframe
#' @export
louvain_clustering <- function(pl,xcoord="V1",ycoord="V2",k=100){

  if(!xcoord%in%names(pl) | !ycoord%in%names(pl)){
    stop("Error! Provided data frame does not contain columns specified in xcoord or ycoord\n")
  }
  if(k >= nrow(pl)){
    k <- nrow(pl)-1
  }

  knn.real = FNN::get.knn(data = as.matrix(pl[,c(xcoord,ycoord)]), k = k)
  knn.real = data.frame(from = rep(1:nrow(knn.real$nn.index),k),
                        to = as.vector(knn.real$nn.index),
                        weight = 1/(1 +as.vector(knn.real$nn.dist)))
  nw.real = igraph::graph_from_data_frame(knn.real, directed = FALSE)
  nw.real = igraph::simplify(nw.real)
  lc.real = igraph::cluster_louvain(nw.real)
  pl$louvain = as.factor(igraph::membership(lc.real))

  return(pl)
}


#' Function to perform dimensionality reduction on the data
#'
#' @param cnt a normalized count matrix
#' @param log.transform Logical whether to transform the values to log2 space, log2+1
#' @param method Method for reduction, PCA or t-SNE
#' @param data.label add extra column to the output with label
#' @import Rtsne
#' @return dataframe
#' @export
pca.plot.df <- function(cnt,log.transform=T,method="PCA",
                        data.label="COPDgene"){
  if(log.transform==T){
    cnt <- log2(cnt+1)
  }
  if(method=="PCA"){
    tcnt <- t(cnt)
    pca_data= stats::prcomp(tcnt)
    scvis =data.frame(V1 = pca_data$x[,1], V2 = pca_data$x[,2])
    scvis$SAMPID <- rownames(scvis)
    scvis$log_likelihood <- 100
    scvis$data <- data.label
    scvis <- louvain_clustering(scvis,"V1","V2",100)
    scvis <- scvis[,c("SAMPID","V1","V2","louvain","log_likelihood","data")]
    rownames(scvis) <- NULL
  }else if(method == "t-SNE"){
    tcnt <- t(cnt)
    z <- Rtsne::Rtsne(tcnt)
    scvis = as.data.frame(z$Y)
    names(scvis)[1:2] <- c("V1","V2")
    scvis$SAMPID <- rownames(tcnt)
    scvis$log_likelihood <- 100
    scvis$data <- data.label
    scvis <- louvain_clustering(scvis,"V1","V2",100)
    scvis <- scvis[,c("SAMPID","V1","V2","louvain","log_likelihood","data")]
    rownames(scvis) <- NULL
  }
  return(scvis)
}



#' Function to summarize the input dataframe
#'
#' @param pl input dataframe
#' @param features fearures used for goruping the data
#' @param ycol column to be summarized
#' @import dplyr
#' @return dataframe
#' @export
cellCountSummary <- function(pl, features='cell_type',ycol='value'){

  z <- pl %>%
    dplyr::group_by_at(features) %>% dplyr::select(dplyr::all_of(ycol)) %>%
    dplyr::summarise_all(c(length))
  z <- as.data.frame(z)
  zncol <- ncol(z)

  names(z)[zncol] <- c("Number of cells")
  z$`total cell count` <- sum(z$`Number of cells`)
  z$percent <- round(z$`Number of cells`*100/z$`total cell count`,3)
  z$percent <- paste0(z$percent,"%")
  z <- z[order(z$`Number of cells`,decreasing = T),]
  z
}


