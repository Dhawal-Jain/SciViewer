# basic plot functions


#' Function provides custom set of colors for plotting
#'
#' Custom colors are selected from qualitative, divergent or sequential pellets.
#' The returned object is a color vector
#' @param k number of colors
#' @param colset which color set to use (seq, qual, div)
#' @param space which color space to use (1 = blue hue, 2 = red hue)
#' @return color vector
#' @export
## color function
myCol.fun <- function(k=2,colset="qual",space=1)
{

  col.list <- list()
  cols <- c()

  if(grep("qual", colset) ){
    if(k <= 8){
      col.list[["qual"]] <- c('#7fc97f','#beaed4','#fdc086','#ffff99','#386cb0','#f0027f','#bf5b17','#666666')
      cols <- col.list[["qual"]][1:k]
    }else if(k > 8 & k <= 12){
      col.list[["qual"]] <- c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928')
      cols <- col.list[["qual"]][1:k]
    } else if(k>12 & k <= 42){
      k <- seq(1,42,length.out = k) %>% floor
      col.list[["random"]] <- c("#ef17ab", "#0e008c", "#023f89", "#11af56", "#2d0870", "#ad0f1f",
                                "#e506c7", "#049b78", "#670791", "#ed10ae", "#b26c03", "#ad0d2b",
                                "#1a930d", "#042366", "#0d8193", "#610a87", "#597a04", "#820116",
                                "#0a3970", "#db0a95", "#077700", "#042360", "#bf0961", "#158e00",
                                "#4b8c01", "#d306c5", "#3f026d", "#7a910a", "#891d00", "#061872",
                                "#029177", "#2f6801", "#0c0277", "#109b06", "#ae13d8", "#dddd11",
                                "#d6158f", "#0f056b", "#c1059f", "#9e2d07", "#af06e8", "#cc1272")
      cols <- col.list[["random"]][k]
    }
  } else if(grep("seq", colset)){
    if(k <= 9){
      k <- seq(1,9,length.out = k) %>% floor
      if(space==1){
        col.list[["seq_blue"]] <- c('#fcfbfd','#efedf5','#dadaeb','#bcbddc','#9e9ac8','#807dba','#6a51a3','#54278f','#3f007d')
        cols <- col.list[["seq_blue"]][k]
      }else if(space==2){
        col.list[["seq_red"]] <- c('#ffffcc','#ffeda0','#fed976','#feb24c','#fd8d3c','#fc4e2a','#e31a1c','#bd0026','#800026')
        cols <- col.list[["seq_red"]][k]
      }
    }
  } else if(grep("div", colset)){
    if(k <= 11){
      k <- seq(1,11,length.out = k) %>% floor
      if(space==2){
        col.list[["div"]] <- c('#a50026','#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850','#006837')
        cols <- col.list[["div"]][k]
      }else if(space==1){
        col.list[["div_rgb"]] <- c('#9e0142','#d53e4f','#f46d43','#fdae61','#fee08b','#ffffbf','#e6f598','#abdda4','#66c2a5','#3288bd','#5e4fa2')
        cols <- col.list[["div_rgb"]][k]

      }
    }
  }

  if(length(cols)==0){
    cols <- NULL
  }
  return(cols)
}


#' Function for violin plot using ggplot2
#'
#' The function allows faceting upto 3 variables in the violin display
#' @param features a vector of upto 3 features
#' @param ycol column name for the Y-axis values to be plotted
#' @param pl input data frame
#' @param log2.transform Logical, if to transform the ycol value
#' @param ylab Y-axis label
#' @param xlab X-axis label
#' @param main Plot label
#' @param plot.ly Logical, whether to return an interactive plot
#' @param hline NULL, numeric baseline value to plot
#' @param configlayout Logical, whether to configure the plot layout
#' @import ggplot2
#' @import dplyr
#' @importFrom plotly ggplotly
#' @return ggplot object
#' @export
plot.violin <- function(features,ycol='value',pl,log.transform=F,
                        ylab='log2(TPM+1)',xlab="",main="geneA",
                        plot.ly=F,hline=NULL,configlayout=T){

  if(length(features)>3){
    features = features[1:3]
  }

  dodge <- position_dodge(width = 0.5)

  data_summary <- function(x) {
    m <- mean(x)
    ymin <- m-1.96*sem(x)
    ymax <- m+1.96*sem(x)
    return(c(y=m,ymin=ymin,ymax=ymax))
  }

  if(log.transform==T){
    pl[,ycol] <- log2(pl[,ycol]+1)
  }

  if(length(features)==1){
    q <- ggplot(pl, aes(x = as.factor(pl[,features[1]])  ,
                        y = pl[,ycol],
                        col = as.factor(pl[,features[1]]) ,
                        fill=as.factor(pl[,features[1]])
                        #text = paste0("</br>",features[1],": ",pl[,features[1]],
                        #              "</br>",ycol,": ",pl[,ycol]
                        #             )
    ))
  }else if(length(features)==2){
    q <- ggplot(pl, aes(x = as.factor(pl[,features[1]]) ,
                        y = pl[,ycol],
                        col =as.factor(pl[,features[2]]) ,
                        fill=as.factor(pl[,features[2]])
                        #text = paste0("</br>",features[1],": ",pl[,features[1]],
                        #              "</br>",features[2],": ",pl[,features[2]],
                        #              "</br>",ycol,": ",pl[,ycol]
                        #             )
    ))
  }else if(length(features)>=3){
    q <- ggplot(pl, aes(x =as.factor(pl[,features[1]]) ,
                        y = pl[,ycol],
                        col =as.factor(pl[,features[2]]) ,
                        fill=as.factor(pl[,features[2]])
                        #text = paste0("</br>",features[1],": ",pl[,features[1]],
                        #              "</br>",features[2],": ",pl[,features[2]],
                        #              "</br>",features[3],": ",pl[,features[3]],
                        #              "</br>",ycol,": ",pl[,ycol]
                        #)
    ))+
      facet_wrap(~as.factor(pl[,features[3]]) ,nrow = 1,scales = "free_x")
  }

  cols <- NULL
  if(length(features)==1){
    cols <- myCol.fun(k = length(unique(pl[,features[1]])))
    if(!is.null(cols)){
      names(cols) <- sort(as.character(levels(as.factor(pl[,features[1]]))))
    }
  }else{
    cols <- myCol.fun(k = length(unique(pl[,features[2]])))
    if(!is.null(cols)){
      names(cols) <- sort(as.character(levels(as.factor(pl[,features[2]]))))
    }
  }
  if(!is.null(cols)){
    q <- q + scale_color_manual(values = cols)+
      scale_fill_manual(values = cols)
  }
  if(!is.null(hline)){
    q <- q + stat_identity(yintercept = hline,col="#addd8e",geom = "hline",
                           linetype="dashed",inherit.aes = T,size=0.75)
  }

  q <- q + geom_violin(position = dodge)+
    #geom_boxplot(width=0.1, fill="white",outlier.size = NULL,position = dodge)+
    stat_summary(fun.data = data_summary,position = dodge,color="#d95f0e")+
    theme_bw()+
    theme(legend.title = element_blank(),
          legend.position = "none",
          axis.title = element_text(size=13,colour = "black"),
          legend.text = element_text(size=12,color="black"),
          strip.text = element_text(size=14,face = 3),
          axis.text = element_text(size=12,colour = "black"),
          axis.text.x = element_text(angle = 45,vjust = 0,hjust = 1),
          plot.title = element_text(size=16,hjust = 0.5,color = "black")) +
    ylab(ylab)+xlab(xlab)+ggtitle(main)

  if(length(cols)<10 & length(features)>1){
    q <- q +theme(legend.position = "right",legend.title = element_blank())
  }

  if(plot.ly==T){
    q <- plotly::ggplotly(q)
    for(i in 1:length(q$x$data)){
      if(length(grep(",\\d+[)]",q$x$data[[i]]$name))>0){
        q$x$data[[i]]$showlegend <- FALSE
      }
      q$x$data[[i]]$text <- NULL
    }

    rows=400
    if(length(features)==1){
      rows=min(800,length(unique(pl[,features[1]]))*200)
    }else if(length(features)==2){
      x <- length(unique(pl[,features[1]]))*200 +
        length(unique(pl[,features[2]]))*100
      rows=min(800,x)
      rm(x)
    }else if(length(features)==3){
      x <- length(unique(pl[,features[1]]))*length(unique(pl[,features[3]]))*200 +
        length(unique(pl[,features[2]]))*100
      rows=min(800,x)
      rm(x)
    }
    if(configlayout==T){
      q <- q %>%
        layout(height = 400, width = (rows) )
    }

  }

  q
}



#' Function for Barplot plot using ggplot2
#'
#' The function allows faceting upto 3 variables in the barplot display
#' @param features a vector of upto 3 features
#' @param ycol column name for the Y-axis values to be plotted
#' @param pl input data frame
#' @param log2.transform Logical, if the ycol value is to be transformed or not
#' @param ylab Y-axis label
#' @param xlab X-axis label
#' @param main Plot label
#' @param plot.ly Logical, whether to return an interactive plot
#' @param hline NULL, Numeric baseline value to draw line at
#' @param configlayout Logical, whether to configure the plot layout
#' @import ggplot2
#' @import dplyr
#' @importFrom plotly ggplotly
#' @return ggplot object
#' @export
plot.bars <- function(features,ycol='logval',pl,log.transform=F,
                      ylab='log2(TPM+1)',xlab="",main="geneA",
                      plot.ly=F,hline=NULL,configlayout=T){

  dodge <- position_dodge(width = 0.5)

  if(log.transform==T){
    pl[,ycol] <- log2(pl[,ycol]+1)
  }
  z <- pl %>%
    dplyr::group_by_at(features) %>% dplyr::select(all_of(ycol)) %>%
    dplyr::summarise_all(c(mean,sem))
  z <- as.data.frame(z)

  if(length(features)==1){
    q <- ggplot(z, aes(x=as.factor(z[,features[1]]) ,
                       y=fn1,
                       fill=as.factor(z[,features[1]])
                       #text = paste0("</br>",features[1],": ",z[,features[1]],
                       #               "</br> mean: ",fn1
                       # )
    ))
  }else if(length(features)==2){
    q <- ggplot(z, aes(x=as.factor(z[,features[1]]) ,
                       y=fn1,
                       fill=as.factor(z[,features[2]])
                       #text = paste0("</br>",features[1],": ",z[,features[1]],
                       #               "</br>",features[2],": ",z[,features[2]],
                       #               "</br> mean: ",fn1
                       # )
    ))
  }else if(length(features)>=3){
    q <- ggplot(z, aes(x=as.factor(z[,features[1]]) ,
                       y=fn1,
                       fill=as.factor(z[,features[2]])
                       #text = paste0("</br>",features[1],": ",z[,features[1]],
                       #               "</br>",features[2],": ",z[,features[2]],
                       #               "</br>",features[3],": ",z[,features[3]],
                       #               "</br> mean: ",fn1
                       # )
    )) +
      facet_wrap(~as.factor(z[,features[3]]) ,nrow = 1,scales = "free_x")
  }

  cols <- NULL
  if(length(features)==1){
    cols <- myCol.fun(k = length(unique(z[,features[1]])))
    if(!is.null(cols)){
      names(cols) <- sort(as.character(levels(as.factor(z[,features[1]]))))
    }
  }else{
    cols <- myCol.fun(k = length(unique(z[,features[2]])))
    if(!is.null(cols)){
      names(cols) <- sort(as.character(levels(as.factor(z[,features[2]]))))
    }
  }
  if(!is.null(cols)){
    q <- q + scale_color_manual(values = cols)+
      scale_fill_manual(values = cols)
  }

  q <- q + geom_bar(stat="identity", color="black",position=dodge) +
    geom_errorbar(aes(ymin=fn1-fn2, ymax=fn1+fn2), width=.2,
                  position=dodge)+
    theme_bw()+
    theme(legend.position = "none",
          axis.title = element_text(size=13,colour = "black"),
          strip.text = element_text(size=14,face = 3),
          axis.text = element_text(size=12,colour = "black"),
          plot.title = element_text(size=16,hjust = 0.5,color = "black"),
          axis.text.x = element_text(angle = 45,vjust = 0,hjust = 1)) +
    ylab(ylab)+xlab(xlab)

  if(length(cols)<10 & length(features)>1){
    q <- q +theme(legend.position = "right",legend.title = element_blank())
  }
  if(!is.null(hline)){
    #q <- q + geom_hline(yintercept = hline,color="#addd8e",linetype="dashed",size=0.75)
    q <- q + stat_identity(yintercept = hline,col="#addd8e",geom = "hline",
                           linetype="dashed",inherit.aes = T,size=0.75)
  }

  if(plot.ly==T){
    q <- plotly::ggplotly(q)
    avail <- c()
    for(i in 1:length(q$x$data)){
      if(length(grep(",\\d+[)]",q$x$data[[i]]$name))>0){
        x <- gsub("[(]","",gsub(",\\d*[)]","",q$x$data[[i]]$name))
        q$x$data[[i]]$name <- q$x$data[[i]]$legendgroup <- x
        if(sum(x%in%avail)==0){
          avail <- c(avail,x)
        }else{
          q$x$data[[i]]$showlegend <- FALSE
        }
      }
      q$x$data[[i]]$text <- NULL
    }

    rows=400
    if(length(features)==1){
      rows=min(800,length(unique(pl[,features[1]]))*200)
    }else if(length(features)==2){
      x <- length(unique(pl[,features[1]]))*200 +
        length(unique(pl[,features[2]]))*100
      rows=min(800,x)
      rm(x)
    }else if(length(features)==3){
      x <- length(unique(pl[,features[1]]))*length(unique(pl[,features[3]]))*200 +
        length(unique(pl[,features[2]]))*100
      rows=min(800,x)
      rm(x)
    }
    if(configlayout==T){
      q <- q %>%
        layout(height = 400, width = (rows) )
    }

  }

  q
}


#' Function for dynamic reordering of the Y-axis values when faceting the plot
#'
#' @param x values to be sorted
#' @param by  group used for sorting
#' @param within within limits
#' @param fun function used
#' @param sep separation, default = "__"
#' @return An ordered vector
#' @export
reorder_within <- function(x, by, within, fun = mean, sep = "___", ...)
{
  new_x <- paste(x, within, sep = sep)
  stats::reorder(new_x, by, FUN = fun)
}

#' Function reorders x_scale of the ggplot object
#'
#' @param sep separation, default = "__"
#' @return An ordered ggplot object
#' @import ggplot2
#' @export
scale_x_reordered <- function(..., sep = "___")
{
  reg <- paste0(sep, ".+$")
  ggplot2::scale_x_discrete(labels = function(x) gsub(reg, "", x), ...)
}


#' Function reorders y_scale of the ggplot object
#'
#' @param sep separation, default = "__"
#' @return An ordered ggplot object
#' @import ggplot2
#' @export
scale_y_reordered <- function(..., sep = "___")
{
  reg <- paste0(sep, ".+$")
  ggplot2::scale_y_discrete(labels = function(x) gsub(reg, "", x), ...)
}


#' Function to plot DEG fold change and Pvalue for a gene as a barplot
#'
#' @param deg data.frame with columns
#' @param plot.ly Logical, whether to make the plotly object (default: T)
#' @param configlayout logical, whether to configure the plot layout (default:T)
#' @return A ggplot object
#' @import ggplot2
#' @import plotly
#' @export
plot.debars <- function(deg,plot.ly=T,configlayout=T){

  nrws <- length(unique(paste0(deg$Var1,deg$Test)))

  q <- ggplot(deg,aes(x=as.factor(Var1),y=logFC,
                      fill= log10_Pval ))+
    facet_wrap(~Test,nrow=1,scales = "free")+
    geom_col(position = "dodge2",color="gray")+theme_minimal()+
    xlab("")+
    scale_y_continuous(limits = c( min(-1,min(deg$logFC)), max(1,max(deg$logFC))  ))+
    scale_fill_gradient2(low="white",mid = "#efedf5",high = "#756bb1",midpoint = 1.3,
                         space = "Lab",limits=c(0, max(10,max(deg$log10_Pval))))+
    geom_hline(yintercept = 0,col="red",size=0.8)+
    theme(axis.text = element_text(size=12,color="black"),
          axis.text.x = element_text(angle = 45,hjust = 1),
          axis.title = element_text(size=13,color="black"),
          strip.text = element_text(size=14,color="black"),
          legend.position="right")

  if(plot.ly==T){
    q <- plotly::ggplotly(q)
    if(configlayout==T){
      q <- q %>%
        layout(height = 400, width = min(c(800,max(c(300,nrws*80)))))
    }
  }
  return(q)
}



#' Function to plot sources of variation as a barplot
#'
#' @param vpg data.frame with columns
#' @param  plot.ly Logical, defailt value is T
#' @return A ggplot object
#' @import ggplot2
#' @import plotly
#' @export
plot.var.sources <- function(vpg,plot.ly=T)
{

  cols <- pddExpn::myCol.fun(k=length(unique(vpg$variable)))

  qq <- ggplot(vpg, aes(x="", y=value, fill=variable))+
    geom_bar(width = 1, stat = "identity")+
    facet_wrap(~Var1,nrow = 1,scales = "free_x")+
    scale_fill_manual(values=cols)+
    theme_bw()+xlab("")+ylab("fraction of varinace \nexplained for the gene")+
    theme(legend.title = element_blank(),
          legend.position = "bottom",
          axis.title = element_text(size=13,colour = "black"),
          axis.text = element_text(size=12,color="black"),
          strip.text = element_text(size=13,color="black"),
          axis.title.x = element_blank(),
          axis.text.x = element_blank())

  if(plot.ly==T){
    qq <- plotly::ggplotly(qq)
  }
  qq
}


#' Function to plot varianace rank plot
#'
#' @param vpout data.frame with variance partition values across all genes and a given covariate
#' @param vpout1 data.frame used for labelling the genes
#' @param metafeature Covariate/Attribute/Metafeture whose contribution is to be plotted across all genes
#' @return A ggplot object
#' @import ggplot2
#' @import ggrepel
#' @export
plot.vpranks <- function(vpout,vpout1,metafeature="COPD")
{
  q <- ggplot(vpout,
              aes(x=1,y=reorder_within(gene_id, vpout[,metafeature], Var1),
                  fill=vpout[,metafeature])) +
    geom_raster() +
    scale_y_reordered()+
    ggrepel::geom_text_repel(data = vpout1,
                             aes(x = 1.5,y = reorder_within(gene_id, vpout1[,metafeature], Var1),
                                 label=label),
                             nudge_x      = 1.5,
                             size         = 5,
                             direction    = "y",
                             force        = 1,
                             angle        = 0,
                             #vjust        = 1,
                             hjust        = 0,
                             segment.size = 0.2,inherit.aes = F)+
    scale_fill_gradient(low = "#fff5f0",high = "#99000d",
                        space = "Lab",na.value = "white")+
    facet_wrap(~ Var1, scales = "free")+
    scale_x_continuous(limits = c(0,3))+
    theme(axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.title = element_blank(),
          axis.ticks = element_blank(),
          strip.background = element_blank(),
          strip.text = element_text(size=20,color="black"),
          legend.position = "bottom",
          legend.text = element_text(size=18,color="black"),
          legend.title = element_blank())
  return(q)
}




#' Function for plotting a gene model
#'
#' The function accepts the gene name and plot the locus using ggbio package
#' @param conn Connection to the SQL database with transcript information
#' @param genename Name of the gene to be plotted
#' @import ggplot2
#' @import ggrepel
#' @import dplyr
#' @import GenomicRanges
#' @import data.table
#' @import plotly
#' @import RSQLite
#' @param exon.struct How to display exon structure in the final gene model (disjoin or union)
#' @return A list of plots along with exon structure
#' @export
plot.genemodel <- function(conn,genename="ACTN3",exon.struct="disjoin"){

  #genename="WNT4"
  query <- paste0("SELECT * FROM gTranscripts WHERE geneSymbol='",genename,"'")

  g <- RSQLite::dbGetQuery(conn, query)
  if(nrow(g)==0){
    stop("Error! Could not find the gene. Double check what you entered!!")
  }

  pllist <- list()
  ## gplotbase
  gbase <-     theme_bw()+
    theme(axis.title = element_blank(),
          axis.text = element_text(size = 11,colour = "black"),
          axis.ticks.y = element_blank(),
          panel.grid.major = element_blank(),
          panel.grid = element_blank(),
          panel.border = element_rect(colour = NA),
          axis.line.x = element_line(colour = "black"))
  strnd <- unique(g$strand)

  ## trx structures
  pllist[["trx"]] <- local({
    ntrx <- g[,c("trx_id","trxstart","trxend")] %>% unique
    ntrx$len <- abs(ntrx$trxend-ntrx$trxstart)
    ntrx <- ntrx[order(ntrx$len,decreasing = T),]
    ntrx <- ntrx[1:10,]
    ntrx$ymin <- (1:nrow(ntrx))-0.3
    ntrx$ymax <- (1:nrow(ntrx))+0.3
    g <- merge(g,ntrx[,c("trx_id","ymin","ymax","len")],by="trx_id")
    g <- g[order(g$trx_id,g$start,decreasing = F),]
    ntrx$y1 <- ntrx$ymin+0.29
    ntrx$y2 <- ntrx$ymax-0.29
    #ntrx[is.na(ntrx)] <- ""

    q <- ggplot(data=g, mapping=aes(xmin=start, xmax=end, ymin=ymin, ymax=ymax,
                                    label = exonNum)) +
      geom_rect(col=ifelse(strnd=="+","#756bb1","#e6550d"),
                fill=ifelse(strnd=="+","#efedf5","#fee6ce"))+
      geom_rect(data=ntrx,
                mapping=aes(xmin=trxstart, xmax=trxend, ymin=y1,ymax=y2),
                inherit.aes = F,
                col=ifelse(strnd=="+","#756bb1","#e6550d"),
                fill=ifelse(strnd=="+","#efedf5","#fee6ce"))+
      scale_x_continuous(labels = function(l){paste0(round(l/1e3,1),"K") })+
      scale_y_continuous(breaks=ntrx$y1,labels = ntrx$trx_id)+
      gbase
    q
  })

  ux <- g[,c("chr","start","end","strand","exon_id")] %>% unique
  ux <- GenomicRanges::makeGRangesFromDataFrame(ux,keep.extra.columns = T)

  if(exon.struct=="union"){
    uq <- GenomicRanges::makeGRangesFromDataFrame(g,keep.extra.columns = T)
    uq <- GenomicRanges::reduce(uq,ignore.strand=T)

  }else{
    uq <- GenomicRanges::makeGRangesFromDataFrame(g,keep.extra.columns = T)
    uq <- GenomicRanges::disjoin(uq)
  }
  uq <- uq %>% as.data.frame
  uq$ymin <- 0.7
  uq$ymax <- 1.3
  uq$strand <- unique(g$strand)
  uq <- uq[order(uq$start,decreasing = F),]
  uq$exonNum <- paste0("exon",ifelse(uq$strand=="+",1:nrow(uq),nrow(uq):1))
  uq$mid <- round((uq$start+uq$end)/2)
  uq <- GenomicRanges::makeGRangesFromDataFrame(uq,keep.extra.columns = T)
  o <- GenomicRanges::findOverlaps(ux,uq,ignore.strand=T) %>% as.data.frame()
  ux$exon_num <- NA
  ux[o$queryHits]$exon_num <- uq[o$subjectHits]$exonNum
  ux <- sort(ux)
  ux <- GenomicRanges::values(ux)%>% as.data.frame
  ux <- ux[,c("exon_num","exon_id")]

  pllist[["exon_arch"]] <- ux
  rm(o,ux)

  pllist[["model"]] <- local({
    ### generate gene model
    uq <- as.data.frame(uq)

    ## get arches
    gl <- c()
    for(f in levels(as.factor(g$trx_id))){
      x <- GenomicRanges::makeGRangesFromDataFrame(g[g$trx_id==f,],keep.extra.columns = T)
      x <- GenomicRanges::gaps(x)
      x <- x[GenomicRanges::start(x)!=1]
      x$trx_id <- f
      x$label <- paste0(f,":",GenomicRanges::start(x),"_",GenomicRanges::end(x))
      gl <- rbind(gl,as.data.frame(x))
      rm(x)
    }
    gl$diff  <- abs(gl$end-gl$start)
    gl$curv = 1 -(gl$diff / max(gl$diff))
    max_diff = max(gl$diff)
    gl$curv[(gl$diff / max_diff) > 0.2] <- .8
    gl$curv[(gl$diff / max_diff) > 0.8] <- .3
    gl$curv[(gl$diff / max_diff) < 0.2] <- .1
    gl$curv <- gl$curv*(-1)
    rm(max_diff)
    ntrx <- data.frame(trxstart=min(uq$start),trxend=max(uq$end),y1=0.99,y2=1.01,strnd=unique(uq$strand) )

    w <- ggplot(data=uq, mapping=aes(xmin=start, xmax=end, ymin=ymin, ymax=ymax)) +
      geom_rect(col=ifelse(strnd=="+","#756bb1","#e6550d"),fill=ifelse(strnd=="+","#efedf5","#fee6ce"))+
      geom_rect(data=ntrx,
                mapping=aes(xmin=trxstart, xmax=trxend, ymin=y1,ymax=y2),
                inherit.aes = F,
                col=ifelse(strnd=="+","#756bb1","#e6550d"),fill=ifelse(strnd=="+","#efedf5","#fee6ce"))+
      ggrepel::geom_text_repel(data = uq,aes(x = mid,y = 1.3,label=exonNum),
                               nudge_y      = 1.7,
                               direction    = "x",
                               angle        = 90,
                               vjust        = 1,
                               segment.size = 0.2,inherit.aes = F)+
      scale_x_continuous(labels = function(l){paste0(round(l/1e3,1),"K") })+
      scale_y_continuous(breaks=c(1),labels = c("gene model"),limits = c(0.6,2))+
      gbase
    if(length(unique(g$trx_id))<5){
      for(i in 1:nrow(gl)){
        w <- w+
          geom_curve(size=1.5,data=gl[i,],
                     aes(x = start, y = 1.3, xend = end, yend = 1.3,col=as.factor(trx_id) ),
                     curvature = gl$curv[i],ncp = 10,inherit.aes = F)
      }
      w <- w + theme(legend.position = "bottom",
                     legend.text = element_text(size=10,colour = "black"),
                     legend.title = element_blank())
    }
    w
  })

  return(pllist)
}


